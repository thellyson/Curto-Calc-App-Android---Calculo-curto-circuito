package softwares.th.curtocalcalfa.naoUsados;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

import softwares.th.curtocalcalfa.R;

public class ListAdapter extends RecyclerView.Adapter<ListAdapter.ViewHolderClient> {

    private String[] dados;

    @NonNull
    @Override
    public ListAdapter.ViewHolderClient onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {

        LayoutInflater layoutInflater = LayoutInflater.from(viewGroup.getContext());
        View view = layoutInflater.inflate(R.layout.lista_obj_tela_cadastroimp, viewGroup, false);

        ViewHolderClient holderClient = new ViewHolderClient(view);

        return holderClient;
    }

    @Override
    public void onBindViewHolder(@NonNull ListAdapter.ViewHolderClient viewHolder, int i) {


        if (this.dados[1] != null) {
            viewHolder.txtNomePrincipal.setText(this.dados[1]);
            viewHolder.txtNomeSecundario.setText(this.dados[1]);
        }

    }

    @Override
    public int getItemCount() {
        return 0;
    }


    public class ViewHolderClient extends RecyclerView.ViewHolder{

        public TextView txtNomePrincipal;
        public TextView txtNomeSecundario;

        public ViewHolderClient(@NonNull View itemView) {
            super(itemView);

            txtNomePrincipal = (TextView) itemView.findViewById(R.id.txtNomePrincipal);
            txtNomeSecundario = (TextView) itemView.findViewById(R.id.txtNomeSecundario);

        }
    }
}
