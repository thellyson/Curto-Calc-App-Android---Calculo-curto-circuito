package softwares.th.curtocalcalfa.fragmentsTelaCurto.Adapters;

import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

import softwares.th.curtocalcalfa.fragmentsTelaCurto.curtoTab1;
import softwares.th.curtocalcalfa.fragmentsTelaCurto.curtoTab2;
import softwares.th.curtocalcalfa.fragmentsTelaCurto.curtoTab3;

public class FragmentsPageAdapter extends FragmentPagerAdapter {

    private  String[] titulos;

    public FragmentsPageAdapter(FragmentManager fm, String[] tabs) {
        super(fm);
        this.titulos = tabs;
    }

    @Override
    public Fragment getItem(int i) {
        switch (i){
            case 0:
                return new curtoTab1();
            case 1:
                return new curtoTab3();         //240302019_4
            case 2:                             //240302019_4
                return new curtoTab2();         //240302019_4

    //240302019_4            return new curtoTab2();
        }

        return null;
    }

    @Override
    public int getCount() {
        int quantidadeTabs = this.titulos.length;
        return quantidadeTabs;
    }

    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        return this.titulos[position];
    }
}
