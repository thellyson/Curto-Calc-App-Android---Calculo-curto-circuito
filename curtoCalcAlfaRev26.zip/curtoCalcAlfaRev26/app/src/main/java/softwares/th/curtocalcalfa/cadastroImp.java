package softwares.th.curtocalcalfa;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ClipData;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import java.io.FileOutputStream;
import java.util.ArrayList;

import static android.view.View.VISIBLE;

public class cadastroImp extends AppCompatActivity {

    //Declaracao dos views da tela
    //////////////////////////////

 //05032019_2   Button botaoCadastroImpedancia;
    EditText impedanciaRealTextView;
    EditText impedanciaImagTextView;
    EditText barraATextView;
    EditText barraBTextView;
    Spinner tipoImpedancia;
    EditText nomeTextView;
    EditText tensaoGeradorTextView;                     //24020219_1
    TextView textoTensaoGerador;                        //24020219_2
    TextView textoUnidadeTensaoGerador;                 //24020219_2
    TextView textoNaBarra;                              //24020219_2
    TextView textoBarraB;                               //24020219_2
    TextView textoTituloAdicionarNovaImp;               //05032019_2


    //Declaracao das variaveis que recebem o valor das Views em tela
    /////////////////////////////////////////////////////////////////
    double valorImpRealTextView;
    double valorImpImagTextView;
    int valorBarraATextView;
    int valorBarraBTextView;
    String valorNomeTextView;
    String valorTipoTextView;
    double valorTensaoGeradorTextView;                  //24020219_1

    //Declaracao das classes
    ////////////////////////


    //Declaracao de variaveis internas usadas
    /////////////////////////////////////////


    //Declaracoes gerais - 05032019_2
    ///////////////////////////
    int codigoImpedancia;
    int provemEdicao;
    int flagApagaImpedancia;

    ArrayAdapter<String> listaTipoImpedanciaAdpter;
    String[] tiposObjetosImpedancia = new String[] {"Gerador", "Transformador", "Linha", "Carga"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro_imp);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        //Adpter do Spinner
        listaTipoImpedanciaAdpter = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item, tiposObjetosImpedancia);

        //Indexando e alocando Views da tela
        ////////////////////////////////////

        impedanciaRealTextView = findViewById(R.id.impReal);
        impedanciaImagTextView = findViewById(R.id.impImag);
        barraATextView = findViewById(R.id.barraA);
        barraBTextView = findViewById(R.id.barraB);
        tipoImpedancia = findViewById(R.id.tipo);
        tipoImpedancia.setAdapter(listaTipoImpedanciaAdpter);
        nomeTextView = findViewById(R.id.nome);
        tensaoGeradorTextView = findViewById(R.id.tensaoGerador);
        textoTensaoGerador = findViewById(R.id.id_textoTensaoGerador);                  //24020219_2
        textoUnidadeTensaoGerador = findViewById(R.id.id_textounidadeTensaoGerador);    //24020219_2
        textoNaBarra = findViewById(R.id.id_textoNaBarra);                              //24020219_2
        textoBarraB = findViewById(R.id.id_textoBarraB);                                //24020219_2
        textoTituloAdicionarNovaImp = findViewById(R.id.id_textAddNovaImpedancia);



        //05032019_2 - inserido bloco abaixo

        //Recebendo valores via Itent vindos do banco de dados para edição de uma impedância
        ///////////////////////////////////////////////////////////////////////////////////

        Intent intentParaEdicao = getIntent();

        if (intentParaEdicao != null) {
            Bundle parametrosRecebidos = intentParaEdicao.getExtras();

            if (parametrosRecebidos != null) {

                double impedanciaReal = parametrosRecebidos.getDouble("impedanciaReal");
                double impedanciaImag = parametrosRecebidos.getDouble("impedanciaImag");
                int barraA = parametrosRecebidos.getInt("barraA");
                int barraB = parametrosRecebidos.getInt("barraB");
                String tipo = parametrosRecebidos.getString("tipo");
                String nome = parametrosRecebidos.getString("nome");
                double tensaoGerador = parametrosRecebidos.getDouble("tensaoGerador");
                codigoImpedancia = parametrosRecebidos.getInt("codigo");
                provemEdicao = parametrosRecebidos.getInt("provemEdicao");

                //Verifica se realmente provem da funcao edicao e preenche campos
                ////////////////////////////////////////////////////////////////

                if (provemEdicao ==1){

                    impedanciaRealTextView.setText(String.valueOf(impedanciaReal));
                    impedanciaImagTextView.setText(String.valueOf(impedanciaImag));
                    barraATextView.setText(String.valueOf(barraA));
                    barraBTextView.setText(String.valueOf(barraB));

                    if (tipo.equals("Gerador"))
                        tipoImpedancia.setSelection(0);

                    if (tipo.equals("Transformador"))
                        tipoImpedancia.setSelection(1);

                    if (tipo.equals("Linha"))
                        tipoImpedancia.setSelection(2);

                    if (tipo.equals("Carga"))
                        tipoImpedancia.setSelection(3);

                    nomeTextView.setText(String.valueOf(nome));

                    tensaoGeradorTextView.setText(String.valueOf(tensaoGerador));

                    textoTituloAdicionarNovaImp.setText("EDITAR IMPEDÂNCIA");

                }



            }
        }

        //05032019_2 - fim do bloco inserido



        //Spiner para realizar alguma funcao quando clicado - 24020219_2
//05032019_2        tipoImpedancia.setSelection(1);
        tipoImpedancia.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                String itemSelecionado = parent.getItemAtPosition(position).toString();

                if (itemSelecionado.equals("Gerador")){
                    mostraParametroTensaoGerador();
                    escondeBarraB();
                }
                else {
                    escondeParametroTensaoGerador();
                }



                if (itemSelecionado.equals("Gerador") || itemSelecionado.equals("Carga")){
                    escondeBarraB();
                }
                else{
                    mostraBarraB();
                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        //24020219_2 - fim do bloco inserido


        //05032019_2 - removido bloco abaixo
        /*
        //Botao de cadastro impedância
        botaoCadastroImpedancia = findViewById(R.id.btCadastraImp);
        botaoCadastroImpedancia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cadastraImpedancia();

            }
        });
        */ //05032019_2 - fim do bloco inserido


    }


    //05032019_2 - inserido bloco abaixo
    //Botoes de menu superior (Cabacalho)
    ////////////////////////////////////

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_cadastroimp, menu);

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();

        switch (id){

            case android.R.id.home:
                voltarTelaListaItens();
                break;

            case R.id.id_addImpedancia:
                cadastraImpedancia();
                break;

            case R.id.id_apagaImpedancia:
                apagaImpedancia();
                break;
        }


        return super.onOptionsItemSelected(item);
    }

    //05032019_2 - fim do bloco inserido


    public void cadastraImpedancia(){

        //Obtem valores dos objetos em tela, com protecao caso estejam null
        //////////////////////////////////////////////////////////////////

        if (impedanciaRealTextView.getText().length() == 0)
            valorImpRealTextView =0.000000000001;                   //11032019_3
//11032019_3            valorImpRealTextView = 0;                       //03032019_1
//03032019_1            valorImpRealTextView = 999999999;
        else
            valorImpRealTextView = Double.parseDouble(impedanciaRealTextView.getText().toString());

        if (impedanciaImagTextView.getText().length() == 0)
            valorImpImagTextView =0.000000000001;                   //11032019_3
//03032019_1            valorImpImagTextView = 999999999;
//11032019_3            valorImpImagTextView = 0;                       //03032019_1
        else
            valorImpImagTextView = Double.parseDouble(impedanciaImagTextView.getText().toString());

        if (barraATextView.getText().length() == 0)
            valorBarraATextView = 0;
        else
            valorBarraATextView = Integer.parseInt(barraATextView.getText().toString());

        if (barraBTextView.getText().length() == 0)
            valorBarraBTextView = 0;
        else
            valorBarraBTextView = Integer.parseInt(barraBTextView.getText().toString());

         valorTipoTextView = (String) tipoImpedancia.getSelectedItem();


        if (nomeTextView.getText().length() == 0)
            valorNomeTextView = "";
        else
            valorNomeTextView = String.valueOf(nomeTextView.getText());

        //24020219_1 - inserido bloco abaixo
        if (tensaoGeradorTextView.getText().length() ==0)
            valorTensaoGeradorTextView = 0;
        else
            valorTensaoGeradorTextView = Double.parseDouble(tensaoGeradorTextView.getText().toString());
        //24020219_1 - fim do bloco inserido

        //Criando Intent para posterior envio dos dados obtidos para a tela de lista de itens
        //////////////////////////////////////////////////////////////////////////////////////


        if (verificaTextos() == 1){
            Intent intent = new Intent(this,listaItens.class);

            Bundle parametrosParaEnviar = new Bundle();

            flagApagaImpedancia=0;                                                          //05032019_2

            parametrosParaEnviar.putDouble("impedanciaReal",valorImpRealTextView);
            parametrosParaEnviar.putDouble("impedanciaImag",valorImpImagTextView);
            parametrosParaEnviar.putInt("barraA",valorBarraATextView);
            parametrosParaEnviar.putInt("barraB",valorBarraBTextView);
            parametrosParaEnviar.putString("tipo",valorTipoTextView);
            parametrosParaEnviar.putString("nome", valorNomeTextView);
            parametrosParaEnviar.putDouble("tensaoGerador", valorTensaoGeradorTextView);    //24020219_1
            parametrosParaEnviar.putInt("provemEdicao", provemEdicao);                      //05032019_2
            parametrosParaEnviar.putInt("codigoImpedancia", codigoImpedancia);              //05032019_2
            parametrosParaEnviar.putInt("flagApagaImpedancia",flagApagaImpedancia);         //05032019_2


            /*
            //Zerando campos, por seguranca
            //////////////////////////////

            impedanciaRealTextView.setText("");
            impedanciaImagTextView.setText("");
            barraATextView.setText("");
            barraBTextView.setText("");
            tipoImpedancia.setAdapter(listaTipoImpedanciaAdpter);
            nomeTextView.setText(null);
            */

            //Startanto valores para enviar e trocando de pagina
            ///////////////////////////////////////////////////

            intent.putExtras(parametrosParaEnviar);
            startActivity(intent);
        }
    }



    public int verificaTextos(){
        //Dialog para programacoes incongruentes
        AlertDialog.Builder alert = new AlertDialog.Builder(this);
        alert.setTitle("Atenção");
        alert.setNegativeButton("Ok", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });

        //11032019_5 - inserido bloco abaixo
        //Primeira restricao: Gerador ou carga sem barra definida

        if (valorBarraATextView == 0 && (valorTipoTextView.equals("Gerador"))){
            alert.setMessage("Deve-se indicar em qual barra o gerador está conectado");
            alert.show();
            return 0;
        }

        if (valorBarraATextView == 0 && (valorTipoTextView.equals("Carga"))){
            alert.setMessage("Deve-se indicar em qual barra a carga está conectada");
            alert.show();
            return 0;
        }

        //11032019_5 - fim do bloco inserido

        //Segunda restricao: Barras iguais independente do tipo
        if (valorBarraATextView == valorBarraBTextView){
            alert.setMessage("Barras programadas não podem ser de valor igual");
            alert.show();
            return 0;
        }

        //Terceira restricao: Gerador nao pode estar entre barras
        //////////////////////////////////////////////////////////

        //11032019_4 - inserido bloco abaixo
        //Fazendo com que caso a impedância seja do tipo gerador, o lado B seja zero (Aterrado)
        if ((valorTipoTextView.equals("Gerador") || valorTipoTextView.equals("Carga")) && valorBarraBTextView >0){
            valorBarraBTextView = 0;
        }

        //11032019_4 - fim do bloco inserido

        if ((valorBarraATextView > 0 && valorBarraBTextView > 0) && valorTipoTextView.equals("Gerador")){
            alert.setMessage("Gerador deve estar aterrado, Apenas um ponto deve estar conectado na barra");
            alert.show();
            return 0;
        }

        //Quarta restricao: Transformador e linha nao podem estar com barra zerada
        ////////////////////////////////////////////////////////////////////////////
        if ((valorBarraATextView == 0 || valorBarraBTextView == 0) && (valorTipoTextView.equals("Transformador") ||
        valorTipoTextView.equals("Linha"))){
            alert.setMessage("Transformador ou linha devem estar entre duas barras existentes");
            alert.show();
            return 0;
        }

        //24020219_1 - Inserido bloco abaixo
        //Quinta restricao: Gerador não pode ter tensão zerada
        ////////////////////////////////////////////////////////////////////////////
        if (valorTensaoGeradorTextView ==0 && valorTipoTextView.equals("Gerador")){
            alert.setMessage("Gerador não pode ter tensão zerada");
            alert.show();
            return 0;
        }
        //24020219_1 - fim do bloco inserido


        return 1;
    }



    //24020219_2 - inserido bloco abaixo

    public void mostraParametroTensaoGerador(){
        tensaoGeradorTextView.setVisibility(View.VISIBLE);
        textoTensaoGerador.setVisibility(View.VISIBLE);
        textoUnidadeTensaoGerador.setVisibility(View.VISIBLE);
    }

    public void escondeParametroTensaoGerador(){
        tensaoGeradorTextView.setVisibility(View.INVISIBLE);
        textoTensaoGerador.setVisibility(View.INVISIBLE);
        textoUnidadeTensaoGerador.setVisibility(View.INVISIBLE);
    }


    public void escondeBarraB(){
        barraBTextView.setVisibility(View.INVISIBLE);
        textoNaBarra.setText("Na barra:");
        textoBarraB.setVisibility(View.INVISIBLE);

    }


    public void mostraBarraB(){
        barraBTextView.setVisibility(View.VISIBLE);
        textoNaBarra.setText("Entre a barra");
        textoBarraB.setVisibility(View.VISIBLE);

    }

    //24020219_2 - fim do bloco inserido

    //05032019_2 - inserido bloco abaixo

    public void voltarTelaListaItens(){
        Intent voltarTela = new Intent(cadastroImp.this,listaItens.class);
        startActivity(voltarTela);
    }

    //Nessa parte é enviada a flag que é usada na tela de lista itens para
    // identificar se é para excluir, tal como o código do banco de dados
    ////////////////////////////////////////////////////////////////
    public void apagaImpedancia(){
        if (provemEdicao==1){
            flagApagaImpedancia=1;
            Intent intentApagaImpedancia = new Intent(cadastroImp.this,listaItens.class);
            Bundle parametrosParaEnviar = new Bundle();

            parametrosParaEnviar.putInt("flagApagaImpedancia",flagApagaImpedancia);
            parametrosParaEnviar.putInt("codigoImpedancia",codigoImpedancia);

            intentApagaImpedancia.putExtras(parametrosParaEnviar);
            startActivity(intentApagaImpedancia);
        }
        else{
            voltarTelaListaItens();
        }


    }

    //05032019_2 - fim do bloco inserido

}
