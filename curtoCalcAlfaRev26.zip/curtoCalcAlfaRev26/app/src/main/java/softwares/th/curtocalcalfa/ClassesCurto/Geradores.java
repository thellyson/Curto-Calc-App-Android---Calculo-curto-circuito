package softwares.th.curtocalcalfa.ClassesCurto;

import flanagan.complex.Complex;

public class Geradores {

    private String nomeGerador;
    private int barraGerador;
    private double tensaoGerador;
    private Complex correnteContribuicaoGerador;


    //Getters e setters
    ////////////////////

    public String getNomeGerador() {
        return nomeGerador;
    }

    public void setNomeGerador(String nomeGerador) {
        this.nomeGerador = nomeGerador;
    }

    public int getBarraGerador() {
        return barraGerador;
    }

    public void setBarraGerador(int barraGerador) {
        this.barraGerador = barraGerador;
    }

    public double getTensaoGerador() {
        return tensaoGerador;
    }

    public void setTensaoGerador(double tensaoGerador) {
        this.tensaoGerador = tensaoGerador;
    }

    public Complex getCorrenteContribuicaoGerador() {
        return correnteContribuicaoGerador;
    }

    public void setCorrenteContribuicaoGerador(Complex correnteContribuicaoGerador) {
        this.correnteContribuicaoGerador = correnteContribuicaoGerador;
    }
}
