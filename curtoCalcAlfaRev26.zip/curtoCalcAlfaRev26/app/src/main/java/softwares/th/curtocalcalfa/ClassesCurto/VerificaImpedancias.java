package softwares.th.curtocalcalfa.ClassesCurto;

import java.util.List;

public class VerificaImpedancias {

    private List<Impedancia> impedancias;
    private int quantidadeBarras;

    public VerificaImpedancias(List<Impedancia> impedanciaList) {

        this.impedancias = impedanciaList;
    }

    //Verifica se na List de impedancia possui algum gerador, caso nao tenha retorna false
    public boolean verificaPossuiGerador(){

        for (int x =0; x < impedancias.size(); x++){

            if (impedancias.get(x).getTipo().equals("Gerador")){
                return true;
            }
        }

        return false;
    }


    //Verifica se a barra x possui alguma impedancia ligada a ela
    public boolean verificaSeBarraPossuiAlgoLigado(int barra){
        for (int x =0; x < impedancias.size(); x++){
            if (impedancias.get(x).getBarraA() == barra || impedancias.get(x).getBarraB() == barra){
                return  true;
            }
        }

        return false;
    }


    //Verifica se os lados da barra nao estao sendo utilizados (Se os dois lados das barras estao zeradas, quer dizer que a barra esta inativa, independente do tipo de impedancia)
    public String verificaSeAlgumaBarraEstaInativa(){

        int auxQuantidBarras = obtemQuantidadeDeBarras();
        String textoVerifBarrasInativas;

        textoVerifBarrasInativas = "Foi programado um sistema com " + String.valueOf(auxQuantidBarras) + " barras, porém as seguintes barras não possuem nenhum equipamento ligado: ";

        for (int valorBarra =1; valorBarra <= auxQuantidBarras; valorBarra++){
            boolean encontouBarraEmAlgumaPosicao=false;
            for (int posicao =0; posicao < impedancias.size(); posicao++){


                if (valorBarra == impedancias.get(posicao).getBarraA() ||  valorBarra == impedancias.get(posicao).getBarraB()){
                    encontouBarraEmAlgumaPosicao = true;
                }
            }

            //Caso nao tenha encontrado barra em nenhuma posicao, plota valor
            if (encontouBarraEmAlgumaPosicao == false){
                textoVerifBarrasInativas = textoVerifBarrasInativas + "<Barra " + String.valueOf(valorBarra) + ">  ";
            }

        }

        if (textoVerifBarrasInativas.length() > 112){
            return textoVerifBarrasInativas;
        }
        else {
            return null;
        }


    }

    public int obtemQuantidadeDeBarras(){

        int quantidadeItensList = impedancias.size();

        for (int x=0; x< quantidadeItensList; x++){
            if (impedancias.get(x).getBarraA() > this.quantidadeBarras)
                this.quantidadeBarras = impedancias.get(x).getBarraA();

            if (impedancias.get(x).getBarraB() > this.quantidadeBarras)
                this.quantidadeBarras = impedancias.get(x).getBarraB();

        }

        return this.quantidadeBarras;
    }


}
