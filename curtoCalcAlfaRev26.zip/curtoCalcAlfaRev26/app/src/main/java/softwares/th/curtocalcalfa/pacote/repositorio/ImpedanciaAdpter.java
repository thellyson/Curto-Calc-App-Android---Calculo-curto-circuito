package softwares.th.curtocalcalfa.pacote.repositorio;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import softwares.th.curtocalcalfa.ClassesCurto.Impedancia;
import softwares.th.curtocalcalfa.R;
import softwares.th.curtocalcalfa.barras;
import softwares.th.curtocalcalfa.cadastroImp;
import softwares.th.curtocalcalfa.listaItens;

public class ImpedanciaAdpter extends BaseAdapter {

    private List<Impedancia> arrayConteudo;
    private Context context;
    public int teste;


    //Construtor

    public ImpedanciaAdpter(List<Impedancia> arrayConteudo, Context context) {
        this.arrayConteudo = arrayConteudo;
        this.context = context;
    }



    @Override
    public int getCount() {
        return arrayConteudo.size();
    }

    @Override
    public Object getItem(int position) {
        return arrayConteudo.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        View v = View.inflate(context, R.layout.lista_obj_tela_cadastroimp,null);
        TextView nome = (TextView) v.findViewById(R.id.txtNomePrincipal);
        TextView valores = (TextView) v.findViewById(R.id.txtNomeSecundario);
        TextView barras = (TextView) v.findViewById(R.id.txtNomeTerciario);
        ImageView icone = (ImageView) v.findViewById(R.id.id_iconeListaImpedancias);


        //Caso nome esteja sem nada, atribue nome padrao - 24020219_3
        ////////////////////////////////////////////////
        if (arrayConteudo.get(position).getNome().equals("")){
            if (arrayConteudo.get(position).getTipo().equals("Gerador")){
                nome.setText("Gerador "+ (position+1));
            }

            if (arrayConteudo.get(position).getTipo().equals("Transformador")){
                nome.setText("Transformador "+ (position+1));
            }

            if (arrayConteudo.get(position).getTipo().equals("Linha")){
                nome.setText("Linha "+ (position+1));
            }

            if (arrayConteudo.get(position).getTipo().equals("Carga")){
                nome.setText("Carga "+ (position+1));
            }
        }
        else{
            nome.setText(arrayConteudo.get(position).getNome());
        }


        //Atribue as barras onde a impedância está conectada - 24020219_3
        ///////////////////////////////////////////////////

        if (arrayConteudo.get(position).getTipo().equals("Gerador")){
            barras.setText("Gerador conectado na barra " + arrayConteudo.get(position).getBarraA());
        }

        if (arrayConteudo.get(position).getTipo().equals("Transformador")){
            barras.setText("Trafo conectado entre barras " + arrayConteudo.get(position).getBarraA() + " e " + arrayConteudo.get(position).getBarraB());
        }

        if (arrayConteudo.get(position).getTipo().equals("Linha")){
            barras.setText("Linha conectada entre barras " + arrayConteudo.get(position).getBarraA() + " e " + arrayConteudo.get(position).getBarraB());
        }

        if (arrayConteudo.get(position).getTipo().equals("Carga")){
            barras.setText("Carga conectada na barra " + arrayConteudo.get(position).getBarraA());
        }

        //Atribue o valor da impedância - 24020219_3
        valores.setText("Valor Impedância: " + String.valueOf(arrayConteudo.get(position).getImpedanciaReal()) +
        " + J" + String.valueOf(arrayConteudo.get(position).getImpedanciaImag()) + "Ω");

        //Atribue imagem conforme tipo de impedancia
        ////////////////////////////////////////////
        if (arrayConteudo.get(position).getTipo().equals("Transformador"))
            icone.setImageResource(R.drawable.trafo);

        if (arrayConteudo.get(position).getTipo().equals("Gerador"))
            icone.setImageResource(R.drawable.gerador);

        if (arrayConteudo.get(position).getTipo().equals("Carga"))
            icone.setImageResource(R.drawable.carga);

        if (arrayConteudo.get(position).getTipo().equals("Linha"))
            icone.setImageResource(R.drawable.linha);


        int tag = (int)getItemId(position);             //05032019_2
        v.setTag("tag" + tag);                          //05032019_2
//05032019_2        v.setTag(arrayConteudo.get(position));


        //05032019_2 - inserido bloco abaixo
        //Realiza funcao de identificar qual item foi clicado, e posteriomente envia esses dados para tela de edicao
        ///////////////////////////////////////////////////////////////////////////////////////////////////////////

        v.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                System.out.println("posição: " + v.getTag());
                System.out.println("Codigo: " + arrayConteudo.get(position).getCodigo());
                System.out.println("Impedância: " + arrayConteudo.get(position).getImpedanciaComplexa());

                Intent intent = new Intent(context, cadastroImp.class);
                Bundle parametrosParaEnviar = new Bundle();

                parametrosParaEnviar.putDouble("impedanciaReal",arrayConteudo.get(position).getImpedanciaReal());
                parametrosParaEnviar.putDouble("impedanciaImag",arrayConteudo.get(position).getImpedanciaImag());
                parametrosParaEnviar.putInt("barraA",arrayConteudo.get(position).getBarraA());
                parametrosParaEnviar.putInt("barraB",arrayConteudo.get(position).getBarraB());
                parametrosParaEnviar.putString("tipo",arrayConteudo.get(position).getTipo());
                parametrosParaEnviar.putString("nome", arrayConteudo.get(position).getNome());
                parametrosParaEnviar.putDouble("tensaoGerador", arrayConteudo.get(position).getTensaoGerador());
                parametrosParaEnviar.putInt("codigo",arrayConteudo.get(position).getCodigo());
                parametrosParaEnviar.putInt("provemEdicao",1);

                intent.putExtras(parametrosParaEnviar);
                context.startActivity(intent);

            }
        });



        //05032019_2 - fim do bloco inserido



        return v;



    }




}
