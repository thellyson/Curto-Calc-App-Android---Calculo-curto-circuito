package softwares.th.curtocalcalfa;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.constraint.ConstraintLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CursorAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

import softwares.th.curtocalcalfa.ClassesCurto.Impedancia;
import softwares.th.curtocalcalfa.ClassesCurto.VerificaImpedancias;
import softwares.th.curtocalcalfa.database.DadosImpedanciasOpenHelper;
import softwares.th.curtocalcalfa.pacote.repositorio.ImpedanciaAdpter;
import softwares.th.curtocalcalfa.pacote.repositorio.ImpedanciasRepositorio;

public class listaItens extends AppCompatActivity {

    //Declaracao Botoes de acao
    /////////////////
    FloatingActionButton botaoMenu;
    Button botaoCadastroImp;
    FloatingActionButton botaoCancelaMenu;
    Button botaoApagaTudo;
    Button botaoCalculaCurto;


    //Declaracao do ListView e objetos para seu funcionamento
    /////////////////////////////////////////////////////////
    ListView listaImpedancias;
    ArrayList<String> arrayListaDadosImpedancias;
    ImpedanciaAdpter impedanciaAdpter;              //Adpter dos dados do banco de dados

    //Declarando Parametros do Banco de dados
    //////////////////////////////
    SQLiteDatabase conexao;                                     //Clase SQLite
    DadosImpedanciasOpenHelper dadosBancoImpedancias;           //Cria Banco
    ImpedanciasRepositorio impedanciasRepositorio;              //Classe que gerencia o banco de dados
    ConstraintLayout layoutListaItens;                          //Apenas para exibir snackbar

    List<Impedancia> impedanciaList;                            //Lista de impedancia de retorno da consulta do banco

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_itens);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        //Referindo botoes em tela:
        ///////////////////////////

        botaoCadastroImp = findViewById(R.id.addImp);
        botaoApagaTudo = findViewById(R.id.bt_apagaTudo);
        botaoCalculaCurto = findViewById(R.id.bt_calculaCurto);
        botaoCancelaMenu = findViewById(R.id.cancelaMenu);

        layoutListaItens = findViewById(R.id.id_layoutListaItens);


        //Cria e Testa de conexao do banco de dados
        ///////////////////////////////////////////
        criaConexao();

        //Recebendo valores via intent da tela de cadastro para posterior atualizacao do banco
        //////////////////////////////////////////////////////////////////////////////////////

        listaImpedancias = findViewById(R.id.listaObjetos);
        arrayListaDadosImpedancias = new ArrayList<String>();


        Intent intent = getIntent();

        if (intent != null){
            Bundle parametrosRecebidos = intent.getExtras();

            if (parametrosRecebidos != null){

               double impedanciaReal = parametrosRecebidos.getDouble("impedanciaReal");
               double impedanciaImag = parametrosRecebidos.getDouble("impedanciaImag");
               int barraA = parametrosRecebidos.getInt("barraA");
               int barraB = parametrosRecebidos.getInt("barraB");
               String tipo = parametrosRecebidos.getString("tipo");
               String nome = parametrosRecebidos.getString("nome");
               double tensaoGerador = parametrosRecebidos.getDouble("tensaoGerador");
               int provemEdicao = parametrosRecebidos.getInt("provemEdicao");           //05032019_2
                int codigoImpedancia = parametrosRecebidos.getInt("codigoImpedancia");           //05032019_2
                int flagApagaImpedancia = parametrosRecebidos.getInt("flagApagaImpedancia");           //05032019_2

               Impedancia impedanciasAdd = new Impedancia();
                impedanciasAdd.setImpedanciaReal(impedanciaReal);
                impedanciasAdd.setImpedanciaImag(impedanciaImag);
                impedanciasAdd.setBarraA(barraA);
                impedanciasAdd.setBarraB(barraB);
                impedanciasAdd.setTipo(tipo);
                impedanciasAdd.setNome(nome);
                impedanciasAdd.setTensaoGerador(tensaoGerador);

                //Insere nova impedancia ao banco de dados ou sobrescreve existente
                ///////////////////////////////////////////////////////////////////
                if (flagApagaImpedancia==1){
                    impedanciasRepositorio.excluir(codigoImpedancia);
                }
                else{
                    if (provemEdicao == 1)
                        impedanciasRepositorio.alterar(impedanciasAdd,codigoImpedancia);
                    else
                        impedanciasRepositorio.inserir(impedanciasAdd);
                }

            }

            atualizaListViewBancoDados();
        }

//        atualizaListViewBancoDados();

        botaoCadastroImp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent chamaCadastroImp = new Intent(listaItens.this,cadastroImp.class);
                startActivity(chamaCadastroImp);

            }
        });
    }

    //240302019_9 - inserido bloco abaixo
    //Botoes de menu superior (Cabacalho)
    ////////////////////////////////////

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_inicial, menu);

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();

        switch (id){

            case R.id.id_botaoTelaConfig:
                irTelaConfiguracoes();
                break;

            case R.id.id_botaoTelaSobre:
                irTelaSobre();
                break;
        }


        return super.onOptionsItemSelected(item);
    }

    public void irTelaConfiguracoes(){
        Intent intentTelaConfiguracoes = new Intent(listaItens.this, configuracoes.class);
        startActivity(intentTelaConfiguracoes);
    }

    public void irTelaSobre(){
        Intent intentTelaSobre = new Intent(listaItens.this, sobre.class);
        startActivity(intentTelaSobre);
    }

    //240302019_9 - fim do bloco inserido


    public  void criaConexao(){
        //Estabelece conexao e testa se a mesma esta ok (Futuramente criar uma classe para encapsular esse bloco)
        ////////////////////////////////////////////////////////////////////////////////////////////////////////

        try{
            dadosBancoImpedancias = new DadosImpedanciasOpenHelper(this);               //Constroi o banco de dados
            conexao = dadosBancoImpedancias.getWritableDatabase();                             //Parametro para permitir editar e ver


            impedanciasRepositorio = new ImpedanciasRepositorio(conexao);                      //Cria um objeto do tipo ImpedanciasRepositorio


        }catch (SQLException ex){
            AlertDialog.Builder alert = new AlertDialog.Builder(this);
            alert.setTitle("Error");
            alert.setMessage("Houve um problema no banco de dados");
            alert.show();
        }
    }


    public void apagaRegistrosBanco(View view){

        impedanciasRepositorio.excluirTudo();

        atualizaListViewBancoDados();

    }


    public void atualizaListViewBancoDados(){

        //Atualizacao da ListView em tela com valores do banco de dados
        ///////////////////////////////////////////////////////////////
        impedanciaList = impedanciasRepositorio.buscarTodos();
//05032019_2        impedanciaAdpter = new ImpedanciaAdpter(impedanciaList,getApplicationContext());
        impedanciaAdpter = new ImpedanciaAdpter(impedanciaList,listaItens.this);        //05032019_2
        listaImpedancias.setAdapter(impedanciaAdpter);

    }

    //Exibir e esconder botoes do menu
    //////////////////////////////////

    @SuppressLint("RestrictedApi")
    public void exibeBotoesMenu(View view){

        botaoCadastroImp.setVisibility(View.VISIBLE);
        botaoCancelaMenu.setVisibility(View.VISIBLE);
        botaoCalculaCurto.setVisibility(View.VISIBLE);
        botaoApagaTudo.setVisibility(View.VISIBLE);
    }

    @SuppressLint("RestrictedApi")
    public void escondeBotoesMenu(View view){

        botaoCadastroImp.setVisibility(View.INVISIBLE);
        botaoCancelaMenu.setVisibility(View.INVISIBLE);
        botaoCalculaCurto.setVisibility(View.INVISIBLE);
        botaoApagaTudo.setVisibility(View.INVISIBLE);

    }

    //Edita impedancia - 05032019_2
    //////////////////////////

    public void excluiImpedancia(int codigo){

        impedanciasRepositorio.excluir(codigo);
        atualizaListViewBancoDados();

    }


    public void editaImpedancia(Impedancia imp, int codigo){
        impedanciasRepositorio.alterar(imp,codigo);
        atualizaListViewBancoDados();
    }



    //Inicia calculo do curto
    /////////////////////////

    public void calculaCurto(View view){

        //Criando intent para troca de tela
        //////////////////////////////////////////////////////////////
        if (verificaSeImpedanciasEstaoOk() == true){                                    //11032019_1
            Intent telaBarras = new Intent(this, barras.class);

            startActivity(telaBarras);
        }                                                                               //11032019_1


    }


    //11032019_1 - inserido bloco abaixo
    //Verifica campos programados das impedancias para caso
    public boolean verificaSeImpedanciasEstaoOk(){

        VerificaImpedancias verificaImpedancias = new VerificaImpedancias(impedanciasRepositorio.buscarTodos());

        //Dialog para programacoes incongruentes
        AlertDialog.Builder alert = new AlertDialog.Builder(this);
        alert.setTitle("Atenção");
        alert.setNegativeButton("Ok", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });

        //Verifica se o sistema possui algum gerador
        ///////////////////////////////////////////
        if (verificaImpedancias.verificaPossuiGerador() == false){
            alert.setMessage("Não é possível realizar o cálculo sem nenhum gerador declarado");
            alert.show();
            return false;
        }

        //Verificar se foi declarado mais barras do que a quantidade de impedâncias associadas
        //////////////////////////////////////////////////////////////////////////////////////
        if (verificaImpedancias.verificaSeAlgumaBarraEstaInativa() != null){
            int quantidadeBarras = verificaImpedancias.obtemQuantidadeDeBarras();

            alert.setMessage(verificaImpedancias.verificaSeAlgumaBarraEstaInativa());
            alert.show();
            return false;
        }

        return true;
    }
    //11032019_1 - fim do bloco inserido
}
