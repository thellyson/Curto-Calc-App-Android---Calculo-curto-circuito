package softwares.th.curtocalcalfa.pacote.repositorio;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import flanagan.complex.Complex;
import softwares.th.curtocalcalfa.ClassesCurto.Impedancia;
import softwares.th.curtocalcalfa.ClassesCurto.PolarConversor;
import softwares.th.curtocalcalfa.ClassesCurto.VerificaImpedancias;
import softwares.th.curtocalcalfa.R;

public class BarrasAdapter extends BaseAdapter {

    private ArrayList<Complex> arrayConteudo;               //240302019_7
    private List<Impedancia> impedanciaList;                //11032019_6
    private Context context;
    private Double[] conteudoVetor;


    private View v;
    private TextView numeroBarra;
    private TextView valorTensaoBarra;
    private String tipoExibicao;            //240302019_7
    private int casasDecimais;              //240302019_7



    public BarrasAdapter(ArrayList<Complex> arrayConteudo, Context context, List<Impedancia> impedanciaList, String tipoPolarRet, int casasDecimais){       //240302019_7
//11032019_6        public BarrasAdapter(ArrayList<String> arrayConteudo, Context context) {
        this.arrayConteudo = arrayConteudo;
        this.context = context;
        this.impedanciaList = impedanciaList;                                                                       //11032019_6
        this.tipoExibicao = tipoPolarRet;               //240302019_7
        this.casasDecimais = casasDecimais;             //240302019_7

    }

    @Override
    public int getCount() {
        return arrayConteudo.size();
    }

    @Override
    public Object getItem(int position) {

        return arrayConteudo.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        //Inflando o layout e instaciando objetos do mesmo
        //////////////////////////////////////////////////

        this.v = View.inflate(context, R.layout.lista_obj_tela_barras, null);

        numeroBarra = (TextView) v.findViewById(R.id.txtNumeroBarra);
        valorTensaoBarra = (TextView) v.findViewById(R.id.txtValorTensaoBarra);

        //Setando textos ja para o listView com o numero da barra e seu valor obtidos do position
        /////////////////////////////////////////////////////////////////////////////////////////

        //11032019_6 - inserido bloco abaixo

        VerificaImpedancias verificaImpedancias = new VerificaImpedancias(this.impedanciaList);

        if (verificaImpedancias.verificaSeBarraPossuiAlgoLigado(position+1) == true){
            numeroBarra.setText("Tensão na barra " + String.valueOf(getItemId(position) + 1));
            //240302019_7 - inserido bloco abaixo
            if (tipoExibicao.equals("Polar")){
                PolarConversor polar = new PolarConversor(this.casasDecimais);
                valorTensaoBarra.setText(String.valueOf(polar.obtemPolar(arrayConteudo.get(position))));
            }
            else{
                PolarConversor retangular = new PolarConversor(this.casasDecimais);
                valorTensaoBarra.setText(String.valueOf(retangular.arredondaValorEmRetangular(arrayConteudo.get(position))));
            }
            //240302019_7 - fim do bloco inserido
        }
        else{
            numeroBarra.setText("Barra " + String.valueOf(getItemId(position) + 1) + " não utilizada");
            valorTensaoBarra.setVisibility(View.INVISIBLE);
        }

        //11032019_6 - fim do bloco inserido



//11032019_6        numeroBarra.setText("Tensão na barra " + String.valueOf(getItemId(position) + 1));
//11032019_6        valorTensaoBarra.setText(String.valueOf(arrayConteudo.get(position)));

        //Setando tag do valor da tensao para posterior consulta
        /////////////////////////////////////////////////

        int tag = (int)getItemId(position);
        valorTensaoBarra.setTag("tag" + tag);


        //03032019_1 - removido bloco abaixo (Futuramente talvez reative)
        /*
        //Recuperando valores apos editar o EditText de acordo com a tag
        ////////////////////////////////////////////////////////////////

        valorTensaoBarra.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {

                if (!hasFocus){         //Apenas entra quando sai do foco (Borda descida)

                    EditText editText = v.findViewById(v.getId());      //Instaciando dinamicamente atraves do Id obtido do onFocusChange. Poderia ser a tag tambem.

                    int indexArrayConteudo = Integer.parseInt(editText.getTag().toString().substring(3));       //Obtendo index via tag eliminando os 3 primeiros caracteres do String

                    String valorConteudo;
                    if (editText.getText().length() != 0) {
                        valorConteudo = editText.getText().toString();
                        arrayConteudo.set(indexArrayConteudo, valorConteudo);
//                        printArrayList();      //apenas para testar
                    }
                    else {
                        valorConteudo = "0";
                        arrayConteudo.set(indexArrayConteudo, valorConteudo);
//                        printArrayList();     //Apenas para testar
                    }
                }

            }
        });

        */ //03032019_1 - fim do bloco removido

        return v;
    }



    public ArrayList<Complex> obtemTensoesAposEdicao() {

        return this.arrayConteudo;
    }

    private void printArrayList(){
        int quntBarras = this.arrayConteudo.size();

        for (int x =0; x < quntBarras; x++){
            System.out.println("Valor do indice " + x + ": " + arrayConteudo.get(x));
        }
    }


    public ArrayList<String> getStringArrayListTensoes(){

        ArrayList<String> arrayList = new ArrayList<String>();

        int quantidadePosicoes = arrayConteudo.size();

        for (int x=0; x < quantidadePosicoes; x++){
            arrayList.add(x, String.valueOf(arrayConteudo.get(x)));
        }
        return  arrayList;
    }


}
