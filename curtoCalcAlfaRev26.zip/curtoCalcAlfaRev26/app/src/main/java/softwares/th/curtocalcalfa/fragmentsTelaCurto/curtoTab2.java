package softwares.th.curtocalcalfa.fragmentsTelaCurto;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import softwares.th.curtocalcalfa.R;
import softwares.th.curtocalcalfa.curto;

public class curtoTab2 extends Fragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.curto_tab2, container, false);
    }

    @Override
    public void onViewCreated (View view, Bundle savedInstanceState) {
        ((curto) getActivity()).onFragmentViewCreatedTab2(view); // Metodo que deve ser implementado na Activity  //07032019_2
    }
}
