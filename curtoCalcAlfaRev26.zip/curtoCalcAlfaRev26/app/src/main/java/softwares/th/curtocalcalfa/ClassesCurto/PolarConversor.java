package softwares.th.curtocalcalfa.ClassesCurto;

import android.content.Context;
import android.content.SharedPreferences;

import java.math.BigDecimal;
import java.math.RoundingMode;

import flanagan.complex.Complex;

public class PolarConversor{

    private int casasDecimais;

    public PolarConversor(int casasDecimais) {
        this.casasDecimais = casasDecimais;
    }

    public String obtemPolar(Complex valorRetangular){
        double valorReal = valorRetangular.getReal();
        double valorImag = valorRetangular.getImag();

        double modulo = Math.sqrt((valorReal*valorReal) + (valorImag*valorImag));

        double angulo = valorRetangular.argDeg();

        BigDecimal moduloArredondado = new BigDecimal(modulo).setScale(this.casasDecimais, RoundingMode.HALF_DOWN);
        BigDecimal anguloArredondado = new BigDecimal(angulo).setScale(this.casasDecimais,RoundingMode.HALF_DOWN);

        String valorPolar = moduloArredondado + " ∠ " + anguloArredondado;

        return valorPolar;
    }

    public String obtemPolar(double real, double imag){

        double valorReal = real;
        double valorImag = imag;

        double modulo = Math.sqrt((valorReal*valorReal) + (valorImag*valorImag));

        Complex auxComplex = new Complex();
        auxComplex.setReal(valorReal);
        auxComplex.setImag(valorImag);
        double angulo = auxComplex.argDeg();

        BigDecimal moduloArredondado = new BigDecimal(modulo).setScale(this.casasDecimais, RoundingMode.HALF_DOWN);
        BigDecimal anguloArredondado = new BigDecimal(angulo).setScale(this.casasDecimais,RoundingMode.HALF_DOWN);

        String valorPolar = moduloArredondado + " ∠ " + anguloArredondado;

        return valorPolar;
    }

    public Complex arredondaValorEmRetangular(Complex valor){

        double valorReal = valor.getReal();
        double valorImag = valor.getImag();

        BigDecimal valorRealArred = new BigDecimal(valorReal).setScale(this.casasDecimais, RoundingMode.HALF_DOWN);
        BigDecimal valorImagArred = new BigDecimal(valorImag).setScale(this.casasDecimais, RoundingMode.HALF_DOWN);

        Complex valorArredondado = new Complex();
        valorArredondado.setReal(valorRealArred.doubleValue());
        valorArredondado.setImag(valorImagArred.doubleValue());

        return valorArredondado;
    }

    public Complex arredondaValorEmRetangular(double real, double imag){

        double valorReal = real;
        double valorImag = imag;

        BigDecimal valorRealArred = new BigDecimal(valorReal).setScale(this.casasDecimais, RoundingMode.HALF_DOWN);
        BigDecimal valorImagArred = new BigDecimal(valorImag).setScale(this.casasDecimais, RoundingMode.HALF_DOWN);

        Complex valorArredondado = new Complex();
        valorArredondado.setReal(valorRealArred.doubleValue());
        valorArredondado.setImag(valorImagArred.doubleValue());

        return valorArredondado;
    }

}
