package softwares.th.curtocalcalfa.database;

public class ScriptDLL {

    public static String getCreateTableCliente(){
        StringBuilder sql = new StringBuilder();


        sql.append("CREATE TABLE IF NOT EXISTS IMPEDANCIA ( ");
        sql.append("        IMPEDANCIAREAL DOUBLE  NOT NULL DEFAULT(0), ");
        sql.append("        IMPEDANCIAIMAG DOUBLE  NOT NULL DEFAULT(0), ");
        sql.append("        BARRAA         INTEGER NOT NULL DEFAULT(0), ");
        sql.append("        BARRAB         INTEGER NOT NULL DEFAULT(0), ");
        sql.append("        TIPO           STRING  NOT NULL DEFAULT(0), ");
        sql.append("        NOME           STRING  NOT NULL DEFAULT(0), ");
        sql.append("        _CODIGO         INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, ");
        sql.append("        TENSAOGERADOR DOUBLE  NOT NULL DEFAULT(0) ");         //24020219_1
        sql.append(");");




        return  sql.toString();
    }
}
