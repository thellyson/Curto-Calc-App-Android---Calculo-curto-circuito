package softwares.th.curtocalcalfa.pacote.repositorio;

import android.content.Context;
import android.content.SharedPreferences;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;

import flanagan.complex.Complex;
import softwares.th.curtocalcalfa.ClassesCurto.Geradores;
import softwares.th.curtocalcalfa.ClassesCurto.PolarConversor;
import softwares.th.curtocalcalfa.R;

public class ContribuicaoGeradoresAdapter extends BaseAdapter {

    private List<Geradores> geradores;
    private Context context;
    private String tipoExibicao;                //240302019_7
    private int casasDecimais;                  //240302019_7


    public ContribuicaoGeradoresAdapter(List<Geradores> arrayConteudo, Context context, String tipoPolarRet, int casasDecimais){    //240302019_7

        this.context = context;
        this.geradores = arrayConteudo;
        this.tipoExibicao = tipoPolarRet;               //240302019_7
        this.casasDecimais = casasDecimais;             //240302019_7

    }

    @Override
    public int getCount() {
        return this.geradores.size();
    }

    @Override
    public Object getItem(int position) {
        return this.geradores.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        //Inflando o layout e instaciando objetos do mesmo
        //////////////////////////////////////////////////

        View v = View.inflate(context, R.layout.lista_obj_curto_contribgeradores, null);

        ImageView imageView = (ImageView) v.findViewById(R.id.id_imagemListaObjContribGeradores);
        TextView textoNomeGerador = (TextView) v.findViewById(R.id.id_textoNomeGeradorListObjContrGeradores);
        TextView textoTensaoGerador = (TextView) v.findViewById(R.id.id_valorTensaoListaObjContrGeradores);
        TextView correnteContribuicao = (TextView) v.findViewById(R.id.id_valorCorrenteListaObjContrGeradores);

        imageView.setImageResource(R.drawable.gerador);
        textoNomeGerador.setText(geradores.get(position).getNomeGerador());
        textoTensaoGerador.setText("Tensão: "+ geradores.get(position).getTensaoGerador() + " p.u.");


        double parteRealCorrenteContr = this.geradores.get(position).getCorrenteContribuicaoGerador().getReal();
        double parteImagCorrenteContr = this.geradores.get(position).getCorrenteContribuicaoGerador().getImag();

        BigDecimal correnteContrArredReal = new BigDecimal(parteRealCorrenteContr).setScale(this.casasDecimais, RoundingMode.HALF_DOWN);
        BigDecimal correnteContrArredImag = new BigDecimal(parteImagCorrenteContr).setScale(this.casasDecimais, RoundingMode.HALF_DOWN);

        Complex correnteContrArred = new Complex();
        correnteContrArred.setReal(correnteContrArredReal.doubleValue());
        correnteContrArred.setImag(correnteContrArredImag.doubleValue());

        //240302019_7 - inserido bloco abaixo
        if (this.tipoExibicao.equals("Polar")){
            PolarConversor correnteContrPolar = new PolarConversor(this.casasDecimais);
            correnteContribuicao.setText(correnteContrPolar.obtemPolar(parteRealCorrenteContr,parteImagCorrenteContr) + " p.u.");
        }
        else{
            correnteContribuicao.setText(String.valueOf(correnteContrArred) + " p.u.");
        }

        //240302019_7 - fim do bloco inserido


        return v;
    }
}
