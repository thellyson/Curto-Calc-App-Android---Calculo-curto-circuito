package softwares.th.curtocalcalfa.pacote.repositorio;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

import softwares.th.curtocalcalfa.ClassesCurto.Impedancia;

public class ImpedanciasRepositorio {


    private SQLiteDatabase conexao;


    public ImpedanciasRepositorio(SQLiteDatabase conexao){
        this.conexao = conexao;
    }


    public void inserir (Impedancia impedancias){

        ContentValues contentValues = new ContentValues();
        contentValues.put("IMPEDANCIAREAL",impedancias.getImpedanciaReal());
        contentValues.put("IMPEDANCIAIMAG", impedancias.getImpedanciaImag());
        contentValues.put("BARRAA",impedancias.getBarraA());
        contentValues.put("BARRAB", impedancias.getBarraB());
        contentValues.put("TIPO", impedancias.getTipo());
        contentValues.put("NOME", impedancias.getNome());
        contentValues.put("TENSAOGERADOR", impedancias.getTensaoGerador());         //24020219_1

        conexao.insertOrThrow("IMPEDANCIA", null, contentValues);

    }

    public void excluir (int codigo){

        String[] parametros = new String[1];                                                //Talvez nao precisasse colocar numa array de String
        parametros[0] = String.valueOf(codigo);                                             //Talvez nao precisasse colocar numa array de String


        conexao.delete("IMPEDANCIA", "_CODIGO = ? ",parametros);

    }


    public void excluirTudo(){
        conexao.execSQL("DELETE FROM " + "IMPEDANCIA");
    }

//05032019_1    public void alterar (Impedancia impedancias){
    public void alterar (Impedancia impedancias, int codigo){                   //05032019_1

        ContentValues contentValues = new ContentValues();
        contentValues.put("IMPEDANCIAREAL",impedancias.getImpedanciaReal());
        contentValues.put("IMPEDANCIAIMAG", impedancias.getImpedanciaImag());
        contentValues.put("BARRAA",impedancias.getBarraA());
        contentValues.put("BARRAB", impedancias.getBarraB());
        contentValues.put("TIPO", impedancias.getTipo());
        contentValues.put("NOME", impedancias.getNome());
        contentValues.put("TENSAOGERADOR", impedancias.getTensaoGerador());         //24020219_1

//05032019_1        String[] parametros = new String[1];                            //Talvez nao precisasse colocar numa array de String
//05032019_1        parametros[0] = String.valueOf(codigo);        //05032019_1 //Talvez nao precisasse colocar numa array de String
//05032019_1        parametros[0] = String.valueOf(impedancias.getCodigo());        //Talvez nao precisasse colocar numa array de String

        String codigoParaAtualizar = String.valueOf(codigo);                //05032019_1

//05032019_1        conexao.update("IMPEDANCIA", contentValues, "_CODIGO = ? ",parametros);
        conexao.update("IMPEDANCIA", contentValues, "_CODIGO=" + codigoParaAtualizar,null);      //05032019_1

    }

    public List<Impedancia> buscarTodos(){

        List<Impedancia> impedanciaList = new ArrayList<Impedancia>();

//        StringBuilder sql = new StringBuilder();
//        sql.append("IMPEDANCIAREAL, IMPEDANCIAIMAG, BARRAA, BARRAB, TIPO, CODIGO");
//        sql.append("FROM IMPEDANCIA");

//        Cursor resultado = conexao.rawQuery(sql.toString(),null);


        String[] colunas = new String[]{"IMPEDANCIAREAL","IMPEDANCIAIMAG","BARRAA","BARRAB","TIPO","_CODIGO", "NOME", "TENSAOGERADOR"};     //24020219_1

        Cursor resultado = conexao.query("IMPEDANCIA", colunas,null, null, null, null, "NOME ASC");

        if (resultado.getCount() > 0){
            resultado.moveToFirst();

            do {

                Impedancia imp = new Impedancia();

                imp.setImpedanciaReal(resultado.getDouble(0));
                imp.setImpedanciaImag(resultado.getDouble(1));
                imp.setBarraA(resultado.getInt(2));
                imp.setBarraB(resultado.getInt(3));
                imp.setTipo(resultado.getString(4));
                imp.setCodigo(resultado.getInt(5));
                imp.setNome(resultado.getString(6));
                imp.setTensaoGerador(resultado.getDouble(7));           //24020219_1


                impedanciaList.add(imp);


            }while (resultado.moveToNext());
        }

        return impedanciaList;
    }

    public Impedancia buscarImpedancia (int codigo) {       //NAO FUNCIONA ATUALMENTE - ARRUMAR DEPOIS

        Impedancia imp = new Impedancia();

//        StringBuilder sql = new StringBuilder();
//        sql.append("IMPEDANCIAREAL, IMPEDANCIAIMAG, BARRAA, BARRAB, TIPO, CODIGO,");
//        sql.append("FROM IMPEDANCIA,");
//        sql.append("WHERE CODIGO = ? ");

        String auxCodigo  = new String("_CODIGO = '" + String.valueOf(codigo) + "'");

//clock        String[] colunas = new String[]{"IMPEDANCIAREAL","IMPEDANCIAIMAG","BARRAA","BARRAB","TIPO","_CODIGO", "NOME"};

        String[] colunas = new String[]{"IMPEDANCIAREAL","IMPEDANCIAIMAG","BARRAA","BARRAB","TIPO",auxCodigo, "NOME", "TENSAOGERADOR"}; //clock

        Cursor resultado = conexao.query("IMPEDANCIA", colunas,null, null, null, null, "TIPO ASC");


//        String[] parametros = new String[1];                //Talvez nao precisasse colocar numa array de String
//        parametros[0] = String.valueOf(codigo);             //Talvez nao precisasse colocar numa array de String
//        Cursor resultado = conexao.rawQuery(sql.toString(), parametros);

        if (resultado.getCount() > 0) {

            resultado.moveToFirst();


            imp.setImpedanciaReal(resultado.getDouble(0));
            imp.setImpedanciaImag(resultado.getDouble(1));
            imp.setBarraA(resultado.getInt(2));
            imp.setBarraB(resultado.getInt(3));
            imp.setTipo(resultado.getString(4));
            imp.setCodigo(resultado.getInt(5));
            imp.setNome(resultado.getString(6));
            imp.setTensaoGerador(resultado.getDouble(7));           //24020219_1

            return imp;

            }

            return null;                            //Muito estranho esse null no final, mas aparentemente funfa
    }

}
