package softwares.th.curtocalcalfa.ClassesCurto;

import android.content.Context;

import java.io.FileOutputStream;

import flanagan.complex.Complex;
import flanagan.complex.ComplexMatrix;

public class Impedancia {

    private double impedanciaReal;
    private double impedanciaImag;
    private int barraA;
    private int barraB;
    private String tipo;
    private double admitanciaReal;
    private double admitanciaImag;
    private int codigo;
    private String nome;
    private double tensaoGerador;       //24020219_1
    private Complex admitanciaComplexa; //03032019_1
    private Complex impedanciaComplexa; //03032019_1



    //Obtem Impedancia complexa - 03032019_1
    ///////////////////////////////////

    public Complex getImpedanciaComplexa(){

        if (this.impedanciaReal == 0)
            this.impedanciaReal=0.000000000001;

        if (this.impedanciaImag == 0)
            this.impedanciaImag=0.000000000001;

        Complex auxImpedanciaComplexa = new Complex();
        auxImpedanciaComplexa.setReal(this.impedanciaReal);
        auxImpedanciaComplexa.setImag(this.impedanciaImag);

        return this.impedanciaComplexa = auxImpedanciaComplexa;
    }


    //Obtem admitancia complexa - 03032019_1
    ///////////////////////////////////

    public Complex getAdmitanciaComplexa(){

        Complex auxValorComplexo = new Complex();
        auxValorComplexo.setReal(this.impedanciaReal);
        auxValorComplexo.setImag(this.impedanciaImag);

        return this.admitanciaComplexa = auxValorComplexo.over(1,auxValorComplexo);
    }


    //Obtem adimitancia imaginaria
    //////////////////////////////

    public double getAdmitanciaImag() {

        //03032019_1 - removido bloco abaixo
        /*
        if (this.impedanciaImag == 0)
            this.admitanciaImag = 999999999;
        else
            this.admitanciaImag = 1 / (this.impedanciaImag);
        */

        //03032019_1 - inserido bloco abaixo

        if (this.impedanciaReal == 0)
            this.impedanciaReal=0.000000000001;

        if (this.impedanciaImag == 0)
            this.impedanciaImag=0.000000000001;

        Complex auxImpedanciaComplexa = new Complex();

        auxImpedanciaComplexa.setReal(this.impedanciaReal);
        auxImpedanciaComplexa.setImag(this.impedanciaImag);

        Complex auxAdmitanciaComplexa = auxImpedanciaComplexa.over(1,auxImpedanciaComplexa);

        return this.admitanciaReal = auxAdmitanciaComplexa.getReal();

        //03032019_1 - fim do bloco inserido


    }


    //Obtem adimitancia real
    //////////////////////////////

    public double getAdmitanciaReal() {

        //03032019_1 - removido bloco abaixo
        /*

        if (this.impedanciaReal == 0)
            this.admitanciaReal = 999999999;
        else
            this.admitanciaReal = 1 / (this.impedanciaReal);

        return this.admitanciaReal;
        */

        //03032019_1 - inserido bloco abaixo

        if (this.impedanciaReal == 0)
            this.impedanciaReal=0.000000001;

        if (this.impedanciaImag == 0)
            this.impedanciaImag=0.000000001;

        Complex auxImpedanciaComplexa = new Complex();

        auxImpedanciaComplexa.setReal(this.impedanciaReal);
        auxImpedanciaComplexa.setImag(this.impedanciaImag);

        Complex auxAdmitanciaComplexa = auxImpedanciaComplexa.over(1,auxImpedanciaComplexa);

        return this.admitanciaImag = auxAdmitanciaComplexa.getImag();

        //03032019_1 - fim do bloco inserido

    }




    /*
    //Construtor
    ////////////

    public Impedancia(double impedancia, int barraImpedanciaA, int barraImpedanciaB, String tipo) {
        this.impedancia = impedancia;
        this.barraImpedanciaA = barraImpedanciaA;
        this.barraImpedanciaB = barraImpedanciaB;
        this.tipo = tipo;
    }
    */

    //Getters e setters
    ////////////////////


    public double getImpedanciaReal() {
        return impedanciaReal;
    }

    public void setImpedanciaReal(double impedanciaReal) {
        this.impedanciaReal = impedanciaReal;
    }

    public double getImpedanciaImag() {
        return impedanciaImag;
    }

    public void setImpedanciaImag(double impedanciaImag) {
        this.impedanciaImag = impedanciaImag;
    }

    public int getBarraA() {
        return barraA;
    }

    public void setBarraA(int barraA) {
        this.barraA = barraA;
    }

    public int getBarraB() {
        return barraB;
    }

    public void setBarraB(int barraB) {
        this.barraB = barraB;
    }

    public void setAdmitanciaReal(double admitanciaReal) {
        this.admitanciaReal = admitanciaReal;
    }

    public void setAdmitanciaImag(double admitanciaImag) {
        this.admitanciaImag = admitanciaImag;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    //24020219_1 - inserido bloco abaixo
    public double getTensaoGerador() {
        return tensaoGerador;
    }

    public void setTensaoGerador(double tensaoGerador) {
        this.tensaoGerador = tensaoGerador;
    }
    //24020219_1 - fim do bloco inserido
}
