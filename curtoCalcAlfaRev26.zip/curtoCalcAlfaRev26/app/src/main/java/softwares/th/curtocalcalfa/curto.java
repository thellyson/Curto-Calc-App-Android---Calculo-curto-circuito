package softwares.th.curtocalcalfa;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.support.constraint.ConstraintLayout;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.GridView;
import android.widget.ListView;
import android.widget.TextView;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;

import flanagan.complex.Complex;
import softwares.th.curtocalcalfa.ClassesCurto.Geradores;
import softwares.th.curtocalcalfa.ClassesCurto.Impedancia;
import softwares.th.curtocalcalfa.ClassesCurto.PolarConversor;
import softwares.th.curtocalcalfa.ClassesCurto.Rede;
import softwares.th.curtocalcalfa.database.DadosImpedanciasOpenHelper;
import softwares.th.curtocalcalfa.fragmentsTelaCurto.Adapters.FragmentsPageAdapter;
import softwares.th.curtocalcalfa.pacote.repositorio.ContribuicaoGeradoresAdapter;
import softwares.th.curtocalcalfa.pacote.repositorio.CurtoOutrasBarrasAdapter;
import softwares.th.curtocalcalfa.pacote.repositorio.ImpedanciasRepositorio;

import static java.lang.Math.abs;

public class curto extends AppCompatActivity {
    //Layout view pager e tab layout
    /////////////////////////////////
    TabLayout tabLayout;
    ViewPager viewPager;


    //TAB 1
    /////////////////

    TextView valorTensaoBarraEscolhida_tab1;
    TextView barraCurto_tab1;
    TextView textoBarraCurto_tab1;
    TextView valorResultadoCorrenteBarraCurto_tab1;

    //Variaveis que recebem valores transferidos via intent
    ////////////////////////////////////////////////////////
    ArrayList<String> arrayListTensoesBarras;
    int valorBarraDesejadaCurto;

    //Declarando Parametros do Banco de dados
    //////////////////////////////
    SQLiteDatabase conexao;                                     //Clase SQLite
    DadosImpedanciasOpenHelper dadosBancoImpedancias;           //Cria Banco
    ImpedanciasRepositorio impedanciasRepositorio;              //Classe que gerencia o banco de dados
    ConstraintLayout layoutListaItens;                          //Apenas para exibir snackbar

    List<Impedancia> impedanciaList;                            //Lista de impedancia de retorno da consulta do banco

    Rede rede;                                                  //07032019_2

    //Tab 2 - 07032019_2
    ///////////////
//240302019_8    ArrayList<String> arrayListCurtoTodasBarras;
    ArrayList<Complex> arrayListCurtoTodasBarras;   //240302019_8
    GridView gridView;

    //Tab 3 - 240302019_4
    ///////////////
    List<Geradores> contribuicoesGeradores;
    TextView textoTituloContrGeradores;
    ListView listViewContrGeradores;

    //Gerais - usados nas tabs
    int casasDecimais;
    String tipoExibicao;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_curto);

        //Cria e Testa de conexao do banco de dados
        ///////////////////////////////////////////
        criaConexao();

        //Buscando valores do banco de dados
        ////////////////////////////////////////////
        impedanciaList = impedanciasRepositorio.buscarTodos();

        //Pegando referencia dos objetos em tela
        ////////////////////////////////////////

        tabLayout = (TabLayout) findViewById(R.id.id_tabCurto1);
        viewPager = (ViewPager) findViewById(R.id.id_viewPagerTelaCurto);


        //Setando View page e linkando no tab layout
        ////////////////////////////////////////////
        viewPager.setAdapter(new FragmentsPageAdapter(getSupportFragmentManager(), getResources().getStringArray(R.array.Titulos_tabs_curto)));
        tabLayout.setupWithViewPager(viewPager);


        //Recebendo valores via intent
        //////////////////////////////

        Intent intent = getIntent();
        Bundle parametrosRecebidos = intent.getExtras();

        if (parametrosRecebidos != null) {
            arrayListTensoesBarras = parametrosRecebidos.getStringArrayList("tensoesBarra");
            valorBarraDesejadaCurto = parametrosRecebidos.getInt("valorBarraDesejadaCurto");

        }

        //Recebendo valores de configuracoes - 240302019_9
        ////////////////////////////////////////////

        SharedPreferences recuperaPreferencias = getSharedPreferences("Preferencias",Context.MODE_PRIVATE);     //240302019_9
        casasDecimais = recuperaPreferencias.getInt("casasDecimais", 3);                                  //240302019_9
        tipoExibicao = recuperaPreferencias.getString("modoExibicaoValores", "Retangular");               //240302019_9


    }

    public  void onFragmentViewCreated(View view){
        valorTensaoBarraEscolhida_tab1 = (TextView) findViewById(R.id.id_valorTensaoBarraCurto);
        barraCurto_tab1 = (TextView)findViewById(R.id.id_numeroBarraEscolhida);
        textoBarraCurto_tab1 = (TextView) findViewById(R.id.id_textoResultado);
        valorResultadoCorrenteBarraCurto_tab1 = (TextView) findViewById(R.id.id_resultadoCurtoTrif);


        barraCurto_tab1.setText("Tensão pré falta na barra " + String.valueOf(valorBarraDesejadaCurto) + ":");


        rede = new Rede(impedanciaList);
        rede.calculaCurtoBarrasComplexa();
        arrayListCurtoTodasBarras = rede.getArrayCorrentesCurtoComplexa();      //07032019_2


        //240302019_8 - inserido bloco abaixo
        //Logica para fazer exibir o valor em polar ou retangular
        if (tipoExibicao.equals("Polar")){
            PolarConversor tensaoBarraSelecPolar = new PolarConversor(casasDecimais);
            valorTensaoBarraEscolhida_tab1.setText(String.valueOf(tensaoBarraSelecPolar.obtemPolar(rede.getItemListTensaoBarraComplexa(valorBarraDesejadaCurto-1)) + " p.u."));
        }
        else{
            PolarConversor tensaoBarraSelecRetang = new PolarConversor(casasDecimais);
            valorTensaoBarraEscolhida_tab1.setText(String.valueOf(tensaoBarraSelecRetang.arredondaValorEmRetangular(rede.getItemListTensaoBarraComplexa(valorBarraDesejadaCurto-1))));
        }

        //240302019_8 - fim do bloco inserido
//03032019_1        rede.calculaCurtoBarrasReal();
//03032019_1        rede.calculaCurtoBarrasImag();

//        double valorArredondadoCorrenteCurto = abs(Double.parseDouble(rede.getCorrenteCurto(valorBarraDesejadaCurto)));
        //03032019_1 - removido bloco abaixo
        /*
        double valorArredondadoCorrenteCurtoReal = Double.parseDouble(rede.getCorrenteCurtoReal(valorBarraDesejadaCurto));
        BigDecimal auxValorArredondadoCorrenteCurtoReal = new BigDecimal(valorArredondadoCorrenteCurtoReal).setScale(2, RoundingMode.HALF_DOWN);


        double valorArredondadoCorrenteCurtoImag = Double.parseDouble(rede.getCorrenteCurtoImag(valorBarraDesejadaCurto));
        BigDecimal auxValorArredondadoCorrenteCurtoImag = new BigDecimal(valorArredondadoCorrenteCurtoImag).setScale(2, RoundingMode.HALF_DOWN);
        */ //03032019_1 - fim do bloco removido



        //03032019_1 - inserido bloco abaixo

        double valorCorrenteCurtoReal = rede.getCorrenteCurtoComplexaReal(valorBarraDesejadaCurto);
    //240302019_8    BigDecimal auxValorArredondadoCorrenteCurtoReal = new BigDecimal(valorCorrenteCurtoReal).setScale(casasDecimais, RoundingMode.HALF_DOWN);


        double valorCorrenteCurtoImag = rede.getCorrenteCurtoComplexaImag(valorBarraDesejadaCurto);
    //240302019_8    BigDecimal auxValorArredondadoCorrenteCurtoImag = new BigDecimal(valorCorrenteCurtoImag).setScale(casasDecimais, RoundingMode.HALF_DOWN);

    //240302019_8 - removido bloco abaixo
    /*
        Complex valorCorrenteCurtoBarraSelec = new Complex();                   //240302019_8
        valorCorrenteCurtoBarraSelec.setReal(valorCorrenteCurtoReal);           //240302019_8
        valorCorrenteCurtoBarraSelec.setImag(valorCorrenteCurtoImag);           //240302019_8

        //07032019_2 - inserido bloco abaixo
        Complex correnteCurtoComplexaArredondada = new Complex();
        correnteCurtoComplexaArredondada.setReal(auxValorArredondadoCorrenteCurtoReal.doubleValue());
        correnteCurtoComplexaArredondada.setImag(auxValorArredondadoCorrenteCurtoImag.doubleValue());
        //07032019_2 - fim do bloco inserido

        //03032019_1 - fim do bloco inserido

        */ //240302019_8 - fim do bloco removido

        //240302019_8 - inserido bloco abaixo
        //Logica para fazer exibir o valor em polar ou retangular
        if (tipoExibicao.equals("Polar")) {
            PolarConversor correnteCurtoPolar = new PolarConversor(casasDecimais);

            textoBarraCurto_tab1.setText("Corrente de curto trifásico na barra " + valorBarraDesejadaCurto + " :");
            valorResultadoCorrenteBarraCurto_tab1.setText(correnteCurtoPolar.obtemPolar(valorCorrenteCurtoReal, valorCorrenteCurtoImag) + " p.u.");
        }
        else
        {
            PolarConversor retangular = new PolarConversor(casasDecimais);
            textoBarraCurto_tab1.setText("Corrente de curto trifásico na barra " + valorBarraDesejadaCurto + " :");
            valorResultadoCorrenteBarraCurto_tab1.setText(String.valueOf(retangular.arredondaValorEmRetangular(valorCorrenteCurtoReal,valorCorrenteCurtoImag)) + " p.u.");
        }
        //240302019_8 - fim do bloco inserido

                 //07032019_2
//07032019_2        valorResultadoCorrenteBarraCurto_tab1.setText(String.valueOf(auxValorArredondadoCorrenteCurtoReal) + " " +
//07032019_2                String.valueOf(auxValorArredondadoCorrenteCurtoImag) + "i " +" p.u.");


    }

    //07032019_2 - inserido bloco abaixo
    public  void onFragmentViewCreatedTab2(View view){

        gridView = findViewById(R.id.id_gridViewCurtoTab2);
        CurtoOutrasBarrasAdapter curtoAdpter = new CurtoOutrasBarrasAdapter(getApplicationContext(),arrayListCurtoTodasBarras,tipoExibicao,casasDecimais);  //240302019_8

        if (rede.getQuantidadeBarras() ==1)
            gridView.setNumColumns(1);

        if (rede.getQuantidadeBarras() >=2)
            gridView.setNumColumns(2);

        if (rede.getQuantidadeBarras() >= 8)
            gridView.setNumColumns(3);

        if (rede.getQuantidadeBarras() >= 16)
            gridView.setNumColumns(4);


        gridView.setAdapter(curtoAdpter);



    }
    //07032019_2 - fim do bloco inserido


    //240302019_4 - inserido bloco abaixo

    public  void onFragmentViewCreatedTab3(View view){

        //Pegando referencia dos objetos em tela
        ///////////////////////////////////////

        listViewContrGeradores = (ListView) findViewById(R.id.id_listViewContribuicoesGeradores);
        textoTituloContrGeradores = (TextView) findViewById(R.id.id_textoTituloContribGeradores);

        contribuicoesGeradores = rede.calculaContribuicaoGeradores(valorBarraDesejadaCurto);
        textoTituloContrGeradores.setText("Contribuição dos geradores para curto na barra " + valorBarraDesejadaCurto);

        System.out.println("Barra curto: " + valorBarraDesejadaCurto);


        //Criando adapter e utilizando
        //////////////////////////////

        ContribuicaoGeradoresAdapter contribuicaoGeradoresAdapter = new ContribuicaoGeradoresAdapter(contribuicoesGeradores,getApplicationContext(),tipoExibicao,casasDecimais);    //240302019_8
        listViewContrGeradores.setAdapter(contribuicaoGeradoresAdapter);



    }

    //240302019_4 - fim do bloco inserido

    public  void criaConexao(){
        //Estabelece conexao e testa se a mesma esta ok (Futuramente criar uma classe para encapsular esse bloco)
        ////////////////////////////////////////////////////////////////////////////////////////////////////////

        try{
            dadosBancoImpedancias = new DadosImpedanciasOpenHelper(this);               //Constroi o banco de dados
            conexao = dadosBancoImpedancias.getWritableDatabase();                             //Parametro para permitir editar e ver


            impedanciasRepositorio = new ImpedanciasRepositorio(conexao);                      //Cria um objeto do tipo ImpedanciasRepositorio


        }catch (SQLException ex){
            AlertDialog.Builder alert = new AlertDialog.Builder(this);
            alert.setTitle("Error");
            alert.setMessage("Houve um problema no banco de dados");
            alert.show();
        }
    }


}
