package softwares.th.curtocalcalfa;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.support.constraint.ConstraintLayout;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import flanagan.complex.Complex;
import softwares.th.curtocalcalfa.ClassesCurto.Impedancia;
import softwares.th.curtocalcalfa.ClassesCurto.Rede;
import softwares.th.curtocalcalfa.database.DadosImpedanciasOpenHelper;
import softwares.th.curtocalcalfa.pacote.repositorio.BarrasAdapter;
import softwares.th.curtocalcalfa.pacote.repositorio.ImpedanciasRepositorio;

public class barras extends AppCompatActivity {

    //Referenciando Views em tela
    /////////////////////////////

    EditText barraDesejada;

    //Declarando Parametros do Banco de dados
    //////////////////////////////
    SQLiteDatabase conexao;                                     //Clase SQLite
    DadosImpedanciasOpenHelper dadosBancoImpedancias;           //Cria Banco
    ImpedanciasRepositorio impedanciasRepositorio;              //Classe que gerencia o banco de dados
    ConstraintLayout layoutListaItens;                          //Apenas para exibir snackbar

    List<Impedancia> impedanciaList;                            //Lista de impedancia de retorno da consulta do banco


    //Rede (Classe que trata o curto)
    Rede rede;

    //Exibicao das tensoes nas barras para edicao
    /////////////////////////////////////////////

    BarrasAdapter barrasAdapter;
    int quantidadeDeBarras;
    ArrayList<Complex> tensoesBarra;            //clock

    //List view edit das tensoes nas barras
    ///////////////////////////////////////
    ListView listViewtensoes;

    ConstraintLayout constraintLayout;                      //Nao usado atualmente

    //Configuracoes - clock
    int casasDecimais;
    String tipoExibicao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_barras);

        //Recebendo valores de configuracoes - clock
        ////////////////////////////////////////////

        SharedPreferences recuperaPreferencias = getSharedPreferences("Preferencias",Context.MODE_PRIVATE);
        casasDecimais = recuperaPreferencias.getInt("casasDecimais", 3);
        tipoExibicao = recuperaPreferencias.getString("modoExibicaoValores", "Retangular");

        //Referenciando objetos da tela
        ////////////////////////////////
        constraintLayout = (ConstraintLayout) findViewById(R.id.id_relativeListaItens);     //Nao usado atualmente
        listViewtensoes = (ListView) findViewById(R.id.id_listViewBarra);
        barraDesejada = (EditText) findViewById(R.id.id_baraCurto);


        //Cria e Testa de conexao do banco de dados
        ///////////////////////////////////////////
        criaConexao();

        //Buscando valores do banco de dados
        ////////////////////////////////////////////
        impedanciaList = impedanciasRepositorio.buscarTodos();


        //Ajuste das barras
        ///////////////////

        rede = new Rede(impedanciaList);

        quantidadeDeBarras = rede.getQuantidadeBarras();      //Calcula a quantidade de barras

        tensoesBarra = rede.getListTensaoBarra();                                //Criando um arrayList com os valores das tensoes das barras em 1pu

        barrasAdapter = new BarrasAdapter(tensoesBarra, getApplicationContext(), impedanciaList,tipoExibicao,casasDecimais);     //clock  //Cria um adpter para o listView do tipo BarrasAdpter

        listViewtensoes.setAdapter(barrasAdapter);                                  //Seta adpter

    }


    public  void criaConexao(){
        //Estabelece conexao e testa se a mesma esta ok (Futuramente criar uma classe para encapsular esse bloco)
        ////////////////////////////////////////////////////////////////////////////////////////////////////////

        try{
            dadosBancoImpedancias = new DadosImpedanciasOpenHelper(this);               //Constroi o banco de dados
            conexao = dadosBancoImpedancias.getWritableDatabase();                             //Parametro para permitir editar e ver


            impedanciasRepositorio = new ImpedanciasRepositorio(conexao);                      //Cria um objeto do tipo ImpedanciasRepositorio


        }catch (SQLException ex){
            AlertDialog.Builder alert = new AlertDialog.Builder(this);
            alert.setTitle("Error");
            alert.setMessage("Houve um problema no banco de dados");
            alert.show();
        }
    }



    public void calculaCurto(View view){

        //Dialog
        ///////
        AlertDialog.Builder alert = new AlertDialog.Builder(this);
        alert.setTitle("Atenção");
        alert.setNegativeButton("Ok", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });

        //Condicao para inicia curto
        ///////////////////////////
        if (barraDesejada.getText().length() != 0){
            int valorBarraDesejadaCurto = Integer.parseInt(barraDesejada.getText().toString());
            if (valorBarraDesejadaCurto > 0 && valorBarraDesejadaCurto <= quantidadeDeBarras){

                Intent irParaTelaCurto = new Intent(this, curto.class);

                Bundle parametrosParaEnviar = new Bundle();

                parametrosParaEnviar.putStringArrayList("tensoesBarra", barrasAdapter.getStringArrayListTensoes());
                parametrosParaEnviar.putInt("valorBarraDesejadaCurto", valorBarraDesejadaCurto);

                irParaTelaCurto.putExtras(parametrosParaEnviar);
                startActivity(irParaTelaCurto);

            }
            else {
                alert.setMessage("Valor da barra para curto não condiz com as barras disponíveis");
                alert.show();
            }
        }
        else {
            alert.setMessage("Barra desejada para curto esta sem nenhum valor");
            alert.show();
        }


    }





}
