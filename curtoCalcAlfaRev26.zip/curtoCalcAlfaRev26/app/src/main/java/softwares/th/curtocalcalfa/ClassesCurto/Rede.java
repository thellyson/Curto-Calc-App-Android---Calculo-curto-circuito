package softwares.th.curtocalcalfa.ClassesCurto;

import android.support.constraint.ConstraintLayout;
import android.support.v7.app.AppCompatActivity;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;

import Jama.Matrix;
import flanagan.complex.Complex;
import flanagan.complex.ComplexMatrix;

import static java.lang.Math.abs;

public class    Rede extends Impedancia{

    private int quantidadeBarras;

    //Tensoes e impedancias
    private ArrayList<Complex> listTensaoBarra;                     //240302019_6
    private ComplexMatrix listTensaoBarraComplexa;                  //03032019_1
    private List<Impedancia> impedanciaList;

    //Matrizes
    private ComplexMatrix matrizAdmitanciaComplexa; //03032019_1
    private ComplexMatrix matrizImpedanciaComplexa; //03032019_1 //Matriz inversa da admitancia
    private ComplexMatrix matrizFontesCorrente;                 //240302019_3 //Matriz das fontes de corrente
    private ComplexMatrix diagPrincipalMatrizImpComplexa;           //03032019_1

    //Resultado
    private ArrayList<String> arrayCorrentesCurtoComplexa;          //03032019_1
    ComplexMatrix matrizCorrentesCurtoCalculadasComplexas;          //03032019_1


    public Rede(List<Impedancia> impedanciaList) {
        this.impedanciaList = impedanciaList;
        obtemQuantidadeDeBarras();
        preencheMatrizYbus();
        calculaTensoesBarra();                                      //23022019_1
        calculaMatrizZbus();
    }


    //Obtem quantidade de barras
    ////////////////////////////

    private int obtemQuantidadeDeBarras(){

        int quantidadeItensList = impedanciaList.size();

        for (int x=0; x< quantidadeItensList; x++){
            if (impedanciaList.get(x).getBarraA() > this.quantidadeBarras)
                this.quantidadeBarras = impedanciaList.get(x).getBarraA();

            if (impedanciaList.get(x).getBarraB() > this.quantidadeBarras)
                this.quantidadeBarras = impedanciaList.get(x).getBarraB();

        }

        return quantidadeBarras;
    }




    //Obtem quantidade de geradores
    ///////////////////////////////

    public int getQuantidadeGeradores(Impedancia[] impedancias){
        int quantGeradores = 0;
        for (int x=0; x < getQuantidadeBarras(); x++){
            if (impedancias[x].getTipo().equals("Gerador")){
                quantGeradores = quantGeradores+1;
            }

        }

        return quantGeradores;
    }


    public void preencheMatrizYbus(){

        ComplexMatrix auxMatrizAdmitanciasComplexa = new ComplexMatrix(this.quantidadeBarras, this.quantidadeBarras);   //03032019_1

        for (int linha=0; linha < this.quantidadeBarras; linha++){

            for (int coluna=0; coluna < this.quantidadeBarras; coluna++){

                Complex auxComplex = new Complex();                     //03032019_1
                auxComplex.setReal(0);                                  //03032019_1
                auxComplex.setImag(0);                                  //03032019_1

                for (int x=0; x < impedanciaList.size(); x++){

                    Complex admComplexa = impedanciaList.get(x).getAdmitanciaComplexa();        //03032019_1
                    String mtipo = impedanciaList.get(x).getTipo();
                    int barA = impedanciaList.get(x).getBarraA();
                    int barB = impedanciaList.get(x).getBarraB();

                    int auxLinha = linha + 1;
                    int auxColuna = coluna +1;

                    if ((barA == auxLinha && barB == auxColuna) || (barB == auxLinha && barA == auxColuna)){
                        auxComplex = auxComplex.plus(auxComplex,admComplexa);                   //03032019_1
                    }

                    if ((auxLinha == auxColuna) && (barA == auxLinha ||  barB == auxLinha )){

                        if (mtipo.equals("Gerador") || mtipo.equals("Carga") || (!mtipo.equals("Gerador") &&  barA !=0 && barB!=0))  {     //23022019_1
                            auxComplex = auxComplex.plus(auxComplex,admComplexa);                   //03032019_1
                        }
                    }


                }
                if (linha == coluna){

                    auxMatrizAdmitanciasComplexa.setElement(linha,coluna,auxComplex);               //03032019_1
                }
                else {

                    auxComplex.setReal(auxComplex.getReal()*-1);                                    //03032019_1
                    auxComplex.setImag(auxComplex.getImag()*-1);                                    //03032019_1
                    auxMatrizAdmitanciasComplexa.setElement(linha,coluna,auxComplex);               //03032019_1
                }


            }
        }

        this.matrizAdmitanciaComplexa = auxMatrizAdmitanciasComplexa;                               //03032019_1

        printaMatrizAdmitanciaComplexa();

    }


    //Calcula as tensoes nas barras - 23022019_1
    ///////////////////////////////

    public void calculaTensoesBarra(){

        //Primeiro passo: Verificar em cada barra se possui gerador e obter seu valor já em fonte de corrente

        ComplexMatrix matrizFontesCorrenteNasBarrasComplexa = new ComplexMatrix(quantidadeBarras,1);        //03032019_1

        for (int x=0; x< impedanciaList.size(); x++){


            if  (impedanciaList.get(x).getTipo().equals("Gerador")){

                Complex auxImpedanciaComplexa = impedanciaList.get(x).getImpedanciaComplexa();           //03032019_1
                double auxTensaoGerador = impedanciaList.get(x).getTensaoGerador();                         //24020219_1

                //Verifica se o lado A da barra tem algum valor
                if (impedanciaList.get(x).getBarraA() >0){

                    //03032019_1 - inserido bloco abaixo

                    //Obtem valor da fonte de corrente
                    Complex auxFonteCorrenteComplexa = auxImpedanciaComplexa.over(auxTensaoGerador,auxImpedanciaComplexa);

                    //Soma valor da fonte de corrente com uma fonte de corrente já existente no endereço
                    Complex resultadoSomaFonteDeCorrenteComValorExistente = auxFonteCorrenteComplexa.plus(
                            auxFonteCorrenteComplexa,
                            matrizFontesCorrenteNasBarrasComplexa.getElementReference(impedanciaList.get(x).getBarraA() -1,0));

                    //Atribui valor
                    matrizFontesCorrenteNasBarrasComplexa.setElement(impedanciaList.get(x).getBarraA() -1,0,
                            resultadoSomaFonteDeCorrenteComValorExistente);
                    //03032019_1 - fim do bloco inserido

                }

                //Verifica se o lado B da barra tem algum valor
                if (impedanciaList.get(x).getBarraB() >0){

                    //03032019_1 - inserido bloco abaixo

                    //Obtem valor da fonte de corrente
                    Complex auxFonteCorrenteComplexa = auxImpedanciaComplexa.over(auxTensaoGerador,auxImpedanciaComplexa);


                    //Soma valor da fonte de corrente com uma fonte de corrente já existente no endereço
                    Complex resultadoSomaFonteDeCorrenteComValorExistente = auxFonteCorrenteComplexa.plus(
                            auxFonteCorrenteComplexa,
                            matrizFontesCorrenteNasBarrasComplexa.getElementReference(impedanciaList.get(x).getBarraB() -1,0));


                    matrizFontesCorrenteNasBarrasComplexa.setElement(impedanciaList.get(x).getBarraB() -1,0,
                            resultadoSomaFonteDeCorrenteComValorExistente);
                    //03032019_1 - fim do bloco inserido

                }

            }
        }

        this.matrizFontesCorrente = matrizFontesCorrenteNasBarrasComplexa;              //240302019_3

        //11032019_2 - inserido bloco abaixo
        //Segundo passo: Verifica se algum valor da barra possui valor null, e atribui valor tendendo a zero
        ////////////////////////////////////////////////////////////////////////////////////////////////////

        for (int linha =0; linha < this.quantidadeBarras; linha++){
            for (int coluna =0; coluna < this.quantidadeBarras; coluna++){
                //Verifica se parte real é igual a zero, caso seja, atribui 0.000000000001

                if (this.matrizAdmitanciaComplexa.getElementReference(linha,coluna).getReal() == 0){
                    //Verifica se está na diagonal principal ou não, e formata de maneira compativel na matriz
                    if (linha == coluna){
                        this.matrizAdmitanciaComplexa.setElement(linha,coluna,0.000000000001,this.matrizAdmitanciaComplexa.getElementReference(linha,coluna).getImag());
                    }
                    else{
                        this.matrizAdmitanciaComplexa.setElement(linha,coluna,-0.000000000001,this.matrizAdmitanciaComplexa.getElementReference(linha,coluna).getImag());
                    }


                }

                //Verifica se parte imag é igual a zero, caso seja, atribui 0.000000000001
                if (this.matrizAdmitanciaComplexa.getElementReference(linha,coluna).getImag() == 0){
                    //Verifica se está na diagonal principal ou não, e formata de maneira compativel na matriz
                    if (linha == coluna) {
                        this.matrizAdmitanciaComplexa.setElement(linha,coluna,this.matrizAdmitanciaComplexa.getElementReference(linha,coluna).getReal(),-0.000000000001);
                    }
                    else {
                        this.matrizAdmitanciaComplexa.setElement(linha,coluna,this.matrizAdmitanciaComplexa.getElementReference(linha,coluna).getReal(),0.000000000001);
                    }

                }
            }
        }

        //11032019_2 - fim do bloco inserido

        //03032019_1 - inserido bloco abaixo
        //Terceiro passo: Inverte matriz, guarda valor e calcula a matriz de tensões
        /////////////////////////////////////////////////////////////
        this.matrizImpedanciaComplexa = matrizAdmitanciaComplexa.inverse();
        ComplexMatrix matrizTensaoCalculadaBarrasComplexo = matrizImpedanciaComplexa.times(matrizFontesCorrenteNasBarrasComplexa);

//        System.out.println("Matriz tensao calcula 0: ");
//        System.out.println(matrizTensaoCalculadaBarrasComplexo.getElementReference(0,0));

//        System.out.println("Matriz tensao calcula 1: ");
//        System.out.println(matrizTensaoCalculadaBarrasComplexo.getElementReference(1,0));



        this.listTensaoBarraComplexa = matrizTensaoCalculadaBarrasComplexo;         //03032019_1

    }


    public void calculaMatrizZbus(){            //Na vdd o nome é preencheDiagonalPrincipal


        //Preenchendo matriz de diagonal principal de impedância
        //////////////////////////////////////////////////////////////////////////////

        int numeroColunas = matrizImpedanciaComplexa.getNcol();
        this.diagPrincipalMatrizImpComplexa = new ComplexMatrix(numeroColunas,1);           //03032019_1
        int auxNumeroColunas = numeroColunas-1;

        for (int x = 0; x <= auxNumeroColunas; x++){

            this.diagPrincipalMatrizImpComplexa.setElement(x,0,matrizImpedanciaComplexa.getElementReference(x,x));

        }

    }


      public void calculaCurtoBarrasComplexa(){
          ArrayList<String> correnteCurtoBarras = new ArrayList<String>();
          this.matrizCorrentesCurtoCalculadasComplexas = new ComplexMatrix(quantidadeBarras,1);

          for (int x=0; x < quantidadeBarras; x++){
              Complex tensaoBarrax;
              tensaoBarrax = listTensaoBarraComplexa.getElementReference(x,0).over(this.diagPrincipalMatrizImpComplexa.getElementReference(x,0));
              this.matrizCorrentesCurtoCalculadasComplexas.setElement(x,0,tensaoBarrax);
              correnteCurtoBarras.add(x, String.valueOf(tensaoBarrax));
          }

          this.arrayCorrentesCurtoComplexa = correnteCurtoBarras;


      }

    //240302019_3 - inserido bloco abaixo
    public List<Geradores> calculaContribuicaoGeradores(int barraSelecionada){

        //Primeiro passo: Cria uma matriz com admitância de curto (Tendendo ao infinito)
        ///////////////////////////////////////////////////////////////////////////////

        ComplexMatrix matrizAdmitanciaCurtoBarraSelec = this.matrizAdmitanciaComplexa;
//        System.out.println("Matriz adm original");                      //TESTE
//        printaMatrizComplexa(matrizAdmitanciaCurtoBarraSelec);          //TESTE

        int auxBarraSelec = barraSelecionada - 1;

        Complex admitanciaCurto = matrizAdmitanciaCurtoBarraSelec.getElementReference(auxBarraSelec,auxBarraSelec);
        Complex admCurto = new Complex();
        admCurto.setReal(1E12);
        admCurto.setImag(-1E12);
        admitanciaCurto = admitanciaCurto.plus(admitanciaCurto,admCurto);

        matrizAdmitanciaCurtoBarraSelec.setElement(auxBarraSelec,auxBarraSelec,admitanciaCurto);

//        System.out.println("Matriz adm CURTO");                         //TESTE
//        printaMatrizComplexa(matrizAdmitanciaCurtoBarraSelec);          //TESTE

        //Segundo passo - Inverte matriz e calcula matriz de tensao pós curto
        ///////////////////////////////////////////////////////////////////

        ComplexMatrix matrizImpedanciaCurtoBarraSelec = matrizAdmitanciaCurtoBarraSelec.inverse();
        ComplexMatrix matrizTensoesPosCurtoBarraSelec = matrizImpedanciaCurtoBarraSelec.times(matrizFontesCorrente);

//        System.out.println("Matriz tensao pos curto");                      //TESTE
//        printaMatrizComplexa(matrizTensoesPosCurtoBarraSelec);              //TESTE


        //Terceiro passo: Varre impedance list e calcula contribuicoes dos geradores
        ////////////////////////////////////////////////////////////////////////////

        List<Geradores> geradores = new ArrayList<Geradores>();


        for (int x=0; x < this.impedanciaList.size(); x++){

            if (this.impedanciaList.get(x).getTipo().equals("Gerador")){
                double auxTensaoGerador = impedanciaList.get(x).getTensaoGerador();
                int barraDoGerador = impedanciaList.get(x).getBarraA();
                double tensaoDeltaBarraGeradorX = abs(abs(auxTensaoGerador) - abs(matrizTensoesPosCurtoBarraSelec.getElementReference((barraDoGerador-1),0).getReal()));
                Complex impGeradorX = impedanciaList.get(x).getImpedanciaComplexa();
                Complex auxTensaoDeltaBarraGeradorX = new Complex();
                auxTensaoDeltaBarraGeradorX.setReal(tensaoDeltaBarraGeradorX);

                Complex auxCorrente = auxTensaoDeltaBarraGeradorX.over(impGeradorX);

                Geradores gx = new Geradores();

                gx.setBarraGerador(barraDoGerador);
                gx.setNomeGerador(impedanciaList.get(x).getNome());
                gx.setTensaoGerador(auxTensaoGerador);
                gx.setCorrenteContribuicaoGerador(auxCorrente);

                geradores.add(gx);

            }
        }


        return geradores;
    }
    //240302019_3 - fim do bloco inserido


    //03032019_1 - inserido bloco abaixo
    public String getCorrenteCurtoComplexa(int barra){
        int auxIndex = barra - 1;
        return arrayCorrentesCurtoComplexa.get(auxIndex);
    }

    public double getCorrenteCurtoComplexaReal(int barra){
        int auxIndex = barra - 1;

        return this.matrizCorrentesCurtoCalculadasComplexas.getElementReference(auxIndex,0).getReal();
    }

    public double getCorrenteCurtoComplexaImag(int barra){
        int auxIndex = barra - 1;

        return this.matrizCorrentesCurtoCalculadasComplexas.getElementReference(auxIndex,0).getImag();
    }


    //03032019_1 - fim do bloco inserido


    public void printaMatrizAdmitanciaComplexa(){
        System.out.println("A seguir será mostrada a matriz de admitancia complexa");

        for (int linha=0; linha < this.quantidadeBarras; linha++){
            System.out.println(" ");

            for (int coluna=0; coluna < this.quantidadeBarras; coluna++){

                System.out.print(" " + this.matrizAdmitanciaComplexa.getElementReference(linha,coluna));
            }
            System.out.println(" ");
        }

    }

    public void printaMatrizComplexa(ComplexMatrix complexMatrix){

        int numeroLinhas = complexMatrix.getNrow();
        int numeroColunas = complexMatrix.getNcol();
        System.out.println(" ");
        for (int linha=0; linha < numeroLinhas; linha++){

            for (int coluna=0; coluna < numeroColunas; coluna++){

                System.out.print(" " + complexMatrix.getElementReference(linha,coluna));
            }
            System.out.println(" ");
        }
    }


    //Getters e setters
    //////////////////

    public int getQuantidadeBarras() {
        return quantidadeBarras;
    }

    public void setQuantidadeBarras(int quantidadeBarras) {
        this.quantidadeBarras = quantidadeBarras;
    }


//240302019_6    public ArrayList<String> getListTensaoBarra() {                     //03032019_1
 public ArrayList<Complex> getListTensaoBarra() {                     //240302019_6

        //03032019_1 - bloco abaixo
//240302019_6        ArrayList<String> auxListTensoes = new ArrayList<String>();
     ArrayList<Complex> auxListTensoes = new ArrayList<Complex>();          //240302019_6

        for (int x=0; x < quantidadeBarras; x++){
            double parteReal = listTensaoBarraComplexa.getElementReference(x,0).getReal();
            double parteImag = listTensaoBarraComplexa.getElementReference(x,0).getImag();

            auxListTensoes.add(x, listTensaoBarraComplexa.getElementReference(x,0));

            //240302019_6 - removido bloco abauixo
            /*
            BigDecimal parteRealAredondada = new BigDecimal(parteReal).setScale(3, RoundingMode.HALF_DOWN);
            BigDecimal parteImagAredondada = new BigDecimal(parteImag).setScale(3, RoundingMode.HALF_DOWN);

            if (parteImagAredondada.doubleValue() >=0)
                auxListTensoes.add(x,String.valueOf(parteRealAredondada + " + j" + parteImagAredondada));
            else
                auxListTensoes.add(x,String.valueOf(parteRealAredondada + " - j" + parteImagAredondada));

            //03032019_1 - fim do bloco
            */ //240302019_6 - fim do bloco removido

        }



        this.listTensaoBarra = auxListTensoes;

        return this.listTensaoBarra;
    }

    //240302019_6 - inserido bloco abaixo

    public Complex getItemListTensaoBarraComplexa(int position){

        return this.listTensaoBarraComplexa.getElementReference(position,0);
    }

    //240302019_6 - fim do bloco inserido

    public void setListTensaoBarra(ArrayList<Complex> listTensaoBarra) {        //240302019_6
        this.listTensaoBarra = listTensaoBarra;
    }

    //07032019_2 -inserido bloco abaixo

//240302019_6    public ArrayList<String> getArrayCorrentesCurtoComplexa() {
public ArrayList<Complex> getArrayCorrentesCurtoComplexa() {

//240302019_6        ArrayList<String> aList = new ArrayList<String>();
        ArrayList<Complex> aList = new ArrayList<Complex>();

        for (int x =0; x < quantidadeBarras; x++){
            double mReal = matrizCorrentesCurtoCalculadasComplexas.getElementReference(x,0).getReal();
            double mImag = matrizCorrentesCurtoCalculadasComplexas.getElementReference(x,0).getImag();

//240302019_6            BigDecimal auxReal = new BigDecimal(mReal).setScale(3, RoundingMode.HALF_DOWN);
//240302019_6            BigDecimal auxImag = new BigDecimal(mImag).setScale(3, RoundingMode.HALF_DOWN);

            Complex auxValorComplexo = new Complex();
//240302019_6            auxValorComplexo.setReal(auxReal.doubleValue());
//240302019_6            auxValorComplexo.setImag(auxImag.doubleValue());

            auxValorComplexo.setReal(mReal);        //240302019_6
            auxValorComplexo.setImag(mImag);        //240302019_6

//240302019_6            aList.add(x, String.valueOf(auxValorComplexo));
            aList.add(x, auxValorComplexo);

        }


        return aList;
    }


    //07032019_2 - fim do bloco inserido
}
