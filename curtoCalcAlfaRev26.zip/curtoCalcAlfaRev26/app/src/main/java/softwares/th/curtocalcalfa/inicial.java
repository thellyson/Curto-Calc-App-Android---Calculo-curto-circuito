/*
//CONTROLE DE REVISOES
//////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////
REV3: CRIADO INTERFACE E MÉTODOS INICIAIS PARA O DESENVOLVIMENTO DO ALGORITIMO DE IDENTIFICACAO
DOS NÓS
DATA: 26-12-2018

///////////////////////////////////////////////////////////////////////////////////////////////
REV6:
- CRIADA INTERFACE INICIAL QUE ADICIONA IMPEDANCIAS NO BANCO DE DADOS, E DEPOIS RESGATA-AS PARA EXIBIR NO LISTVIEW
- MELHORADO CODIGO
- INSERIDO BANCO DE DADOS E CLASSES DA PASTA DATA BASE
- INSERIDO PASTA PACOTE REPOSITORIO QUE TRATA CLASSE IMPEDÂNCIA PARA O BANCO DE DADOS
DATA: 30-12-2018

///////////////////////////////////////////////////////////////////////////////////////////////
REV11: CONCLUIDA PARTE FUNCIONAL BASICA DO APP, CALCULANDO CURTO NA BARRA SELECIONADA, DESDE QUE PROGRAMADO OS PARAMETROS
CORRETAMENTE, CASO CONTRARIO P APP FECHA
- INSERIDO TELA DE EXIBICAO DOS VALORES E TELA DE AJUSTE DA TENSAO NA BARRA
DATA: 13-01-2018

///////////////////////////////////////////////////////////////////////////////////////////////
REV12: AJUSTES GERAIS NO FUNCIONAMENTO E LAYOUT
- NA REVISÃO 12 A PARTE FUNCIONAL DO APP ESTÁ CONCLUIDA, PORÉM O SEU FUNCIONAMENTO SO ABRANGE SISTEMAS EM ABERTO, SEM CARGA
- NAS PRÓXIMAS REVISÕES DEVE-SE ADPTAR O ALGORITIMO DE FORMA QUE O MESMO TRABALHE COM FONTE DE CORRENTE. ENTENDER BEM AS ]
ALTERAÇÕES E APLICAR
- OUTRO PONTO IMPORTANTE É A CORREÇÃO DO MÉTODO REAL-IMAGINÁRIO. ATUALMENTE ELE É CALCULADO EM DUAS MATRIZES, MAS ISSO APARANTIMENTE NAO
ESTÁ CERTO, NA VERDADE OS DOIS DEVEM SER SOMADOS QUADRATICAMENTE E SEU ÂNGULO SALVO EM UMA OUTRA MATRIZ PARA POSTERIOR ADIÇÃO

///////////////////////////////////////////////////////////////////////////////////////////////
REV13: CRIAR CALCULO DAS TENSOES DAS BARRAS PRÉ FALTA COM BASE NAS FONTES DE CORRENTE DO SISTEM
- 23022019_1    CRIADO CÁLCULO AUTOMÁTICO DAS BARRAS PRÉ FALTA COM BASE NAS FONTES DE CORRENTE DO SISTEMA.
Para tal foi inserido o método calculaTensoesBarra(), e chamado no construtor.
- 23022019_2    Removido passo de desprezar as impedâncias que não contribuem no curto

///////////////////////////////////////////////////////////////////////////////////////////////
REV14: IMPLEMENTAR TENSÃO PROGRAMÁVEL DO GERADOR
- 24020219_1 Inserido programacao da tensao do gerador na tela de cadastro impedância, tal como adicionado na lista do banco de dados e implementado na clasa Rede

///////////////////////////////////////////////////////////////////////////////////////////////
REV15: MELHORIAS
- 24020219_2 Inserido atributos visiveis e invisiveis dependendo do tipo de impedancia selecionada

///////////////////////////////////////////////////////////////////////////////////////////////
REV16: MELHORIAS NA PARTE GRÁFICA
- 24020219_3   Inserido imagens para cada tipo de impedancia na lista de visualizações e melhorado layout geral

REV17: CORREÇÕES
- 26022019_1  Corrigido bloco que armazena a tensão na matriz de tensão da classe Rede

REV18: Inserido método via ComplexMatrix
- 03032019_1 Removido método antigo de real / imag separada e inserido funcionamento usando a classe ComplexMatrix que faz todos os cálculos em complexo

REV19: Implementações das funções de editar e excluir
- 05032019_1 Corrigido métodos de excluir e editar itens unitários do banco
- 05032019_2 Implementada funcoes para editar e excluir impedâncias, tal como melhorada interface da tela de cadastro impedancia. Botao de adicionar agora é um icone na parte superior

REV20: Melhorias e recursos
DATA: 07/03/2019
- 07032019_1 Melhoria nas telas (Dimensões e compatibilidade com celulares menores)
- 07032019_2 Inserido visualização da coluna de curto em todas as barras. Criada classe CurtoOutrasBarrasAdapter

REV21: COLOCADO LOGO

REV22: MELHORIA CONTRA PROGRAMAÇÃO ERRADA QUE FAÇA O APP FECHAR
DATA: 11/03/2019
- 11032019_1 Criada Classe VerificaImpedancias que trata possiveis incongruencias na programação. Essa classe foi usada no listaItens.java, não deixando iniciar o cálculo caso algo esteja errado.
- 11032019_2 Inserido passo na classe Rede.java que verifica se algum valor da matriz é = 0, caso seja, atribui 0,00000000001.
- 11032019_3 Na cadastroImp.java, foi feito que o valor real e imag das impedâncias caso seja null ou zero, atribua 0,00000000001, por segurança
- 11032019_4 Inserida nova restricao na cadastroImp.java que automaticamente atribue 0 no lado barraB caso essa impedância seja gerador ou carga
- 11032019_5 Inserida novas restrições no cadastroImp.java que nao deixa programar Gerador ou Carga com barraA zerada
- 11032019_6 Feito com que na classe BarrasAdapter.java, caso alguma barra não possua impedância conectada, é exibido qo texto na barra informando que ela não está sendo utilizada. (Atualmente nunca vai entrar nessa lógica, fiz apenas por segurança) Na barras.java foi necessário alterar o construtor da classe BarrasAdapter.java

REV23: IMPLEMENTAÇÃO DA CONTRIBUIÇÃO DOS GERADORES
DATA: 24/03/2019
- 240302019_1 Inserido Classe Geradores.java para organizar os principais dados dos geradores, e para exibir a contribuicao no list view
- 240302019_2 Inserido classe ContribuicaoGeradoresAdapter.java para o list view da tela de contribuicoes (Tab 3)
- 240302019_3 Inserido método calculaContribuicaoGeradores para calcular contribuições dos geradores na classe Rede.java
- 240302019_4 Inserida nova tab para exibir a contribuicao dos geradores

REV24: IMPLEMENTAÇÕES DE CONFIGURAÇÕES E EXIBIÇÕES DO RESULTADO EM POLAR E RETANGULAR
DATA: 24/03/2019
- 240302019_5 Criada classe PolarConversor.java, que converte e arredonda o valor de uma classe do tipo Complex
- 240302019_6 Adptado clase Rede.java para trabalhar com a selecao do tipo de exibicao. Agora nenhum valor nessa classe é arredondado.
- 240302019_7 Modificada classes de adaptadores (com excessão do impedanciaAdapter), para considerarem o formato do número complexo e as casas decimais para arredondar. Esses parâmetreos são definidos no construtor.
- 240302019_8 Modificado conteudo da tela de curto (curto.java) para considerar a opção do formato do número complexo
- 240302019_9 Inseridas telas de configurações e sobre, tal como implementado SharedPreferences nas principais telas do app para recuperar dados de configurações

REV25: PEQUENAS MUDANÇAS EM TELA
DATA: 31-03-2019
- 31032019_1 Alterado detalhes de alinhamento de tela e mudado texto do sobre


REV26: MUDANÇAS EM TELA E PREPARAÇÃO PARA PUBLICAR APP NA PLAY STORE
DATA: 31-05-2019
- 31052019_1 Modifiquei algumas coisas em tela para publicar na play store
- 31052019_2 removido depuracao (Não pode gerar app final com depuração ativa) no arquivo AndroidManifest.xml
- 31052019_3 Removido Snackbar da tela inicia que informava quando conectado com sucesso ao banco de dados
*/




package softwares.th.curtocalcalfa;

import android.content.Intent;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.support.constraint.ConstraintLayout;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;

import softwares.th.curtocalcalfa.database.DadosImpedanciasOpenHelper;
import softwares.th.curtocalcalfa.pacote.repositorio.ImpedanciasRepositorio;

public class inicial extends AppCompatActivity {


    //Declarando Parametros do Banco de dados
    //////////////////////////////
    SQLiteDatabase conexao;                                     //Clase SQLite
    DadosImpedanciasOpenHelper dadosBancoImpedancias;           //Cria Banco
    ImpedanciasRepositorio impedanciasRepositorio;              //Classe que gerencia o banco de dados
    ConstraintLayout layoutListaItens;                          //Apenas para exibir snackbar

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inicial);

        layoutListaItens = findViewById(R.id.id_layoutInicial);

        //Teste de conexao do banco de dados
        ////////////////////////////////////
        criaConexao();
    }


    public void irParaTelaProcesso(View view) {
        Intent intentTelaProcesso = new Intent(inicial.this, listaItens.class);
        startActivity(intentTelaProcesso);

    }


    public void novoProjeto(View view) {

        impedanciasRepositorio.excluirTudo();

        Intent intentTelaProcesso = new Intent(inicial.this, listaItens.class);
        startActivity(intentTelaProcesso);


    }


    public void criaConexao() {
        //Estabelece conexao e testa se a mesma esta ok (Futuramente criar uma classe para encapsular esse bloco)
        ////////////////////////////////////////////////////////////////////////////////////////////////////////

        try {
            dadosBancoImpedancias = new DadosImpedanciasOpenHelper(this);               //Constroi o banco de dados
            conexao = dadosBancoImpedancias.getWritableDatabase();                             //Parametro para permitir editar e ver


   //31052019_3         Snackbar.make(layoutListaItens, "Conectado com sucesso ao banco de dados", Snackbar.LENGTH_SHORT)
   //31052019_3                 .setAction("Ok", null).show();

            impedanciasRepositorio = new ImpedanciasRepositorio(conexao);


        } catch (SQLException ex) {
            AlertDialog.Builder alert = new AlertDialog.Builder(this);
            alert.setTitle("Error");
            alert.setMessage("Ocorreu um erro no banco de dados");
            alert.show();
        }
    }

    //240302019_9 - inserido bloco abaixo
    //Botoes de menu superior (Cabacalho)
    ////////////////////////////////////

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_inicial, menu);

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();

        switch (id){

            case R.id.id_botaoTelaConfig:
                irTelaConfiguracoes();
                break;

            case R.id.id_botaoTelaSobre:
                irTelaSobre();
                break;
        }


        return super.onOptionsItemSelected(item);
    }

    public void irTelaConfiguracoes(){
        Intent intentTelaConfiguracoes = new Intent(inicial.this, configuracoes.class);
        startActivity(intentTelaConfiguracoes);
    }

    public void irTelaSobre(){
        Intent intentTelaSobre = new Intent(inicial.this, sobre.class);
        startActivity(intentTelaSobre);
    }

    //240302019_9 - fim do bloco inserido




}