package softwares.th.curtocalcalfa.pacote.repositorio;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridLayout;
import android.widget.TextView;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import flanagan.complex.Complex;
import softwares.th.curtocalcalfa.ClassesCurto.PolarConversor;
import softwares.th.curtocalcalfa.ClassesCurto.Rede;
import softwares.th.curtocalcalfa.R;

public class CurtoOutrasBarrasAdapter extends BaseAdapter {

    private ArrayList<Complex> listCurtoBarras;
    private Context context;
    private LayoutInflater layoutInflater;
    private View v;
    private String tipoExibicao;            //240302019_7
    private int casasDecimais;              //240302019_7



    public CurtoOutrasBarrasAdapter(Context context, ArrayList<Complex> listCurtoBarras, String tipoPolarRet, int casasDecimais){    //240302019_7

        this.listCurtoBarras = listCurtoBarras;
        this.context = context;
        this.tipoExibicao = tipoPolarRet;               //240302019_7
        this.casasDecimais = casasDecimais;             //240302019_7

    }

    @Override
    public int getCount() {
        return listCurtoBarras.size();
    }

    @Override
    public Object getItem(int position) {
        return listCurtoBarras.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

//        if (convertView == null){
 //           convertView = layoutInflater.inflate(R.layout.lista_obj_curto_todas_barras, parent, false);
            this.v = View.inflate(context,R.layout.lista_obj_curto_todas_barras,null);

            TextView nomeBarraCurtoTodasBarras = v.findViewById(R.id.id_nomeBarraCurtoTodasBarras);
            TextView valorCurtoTodasBarras = v.findViewById(R.id.id_valorCorrenteCurtoTodasBarras);

            nomeBarraCurtoTodasBarras.setText("BARRA " + String.valueOf(position+1));

            //240302019_7 - inserido bloco abaixo
            if (tipoExibicao.equals("Polar")){
                PolarConversor valorCurtoTodasBarrasPolar = new PolarConversor(this.casasDecimais);
                valorCurtoTodasBarras.setText(String.valueOf(valorCurtoTodasBarrasPolar.obtemPolar(listCurtoBarras.get(position))) + " p.u.");
            }
            else{
                PolarConversor auxValor = new PolarConversor(casasDecimais);
                Complex valorArredondado = auxValor.arredondaValorEmRetangular(listCurtoBarras.get(position));
                valorCurtoTodasBarras.setText(String.valueOf(valorArredondado) + " p.u.");
            }
            //240302019_7 - fim do bloco inserido


 //       }




        return v;
    }
}
