package softwares.th.curtocalcalfa;

import android.content.Context;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class configuracoes extends AppCompatActivity {

    Spinner selecaoModoExibicao;
    EditText valorCasasDecimais;
    ArrayAdapter<String> adpterModoExibicao;
    String[] stringModoExibicao = new String[]{"Polar", "Retangular"};
    int casasDecimais;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_configuracoes);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        selecaoModoExibicao = (Spinner) findViewById(R.id.id_spinnerModoExibicaoValores);
        valorCasasDecimais = (EditText) findViewById(R.id.id_casasDecimais);
        adpterModoExibicao = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,stringModoExibicao);

        selecaoModoExibicao.setAdapter(adpterModoExibicao);

        //Recuperando valores das preferencias
        //////////////////////////////////////

        SharedPreferences recuperaPreferencias = getSharedPreferences("Preferencias",Context.MODE_PRIVATE);

        //Spinner

        if (recuperaPreferencias.getString("modoExibicaoValores", "Erro").equals("Polar")){
            selecaoModoExibicao.setSelection(0);
        }

        if (recuperaPreferencias.getString("modoExibicaoValores", "Erro").equals("Retangular")){
            selecaoModoExibicao.setSelection(1);
        }

        if (recuperaPreferencias.getString("modoExibicaoValores", "Erro").equals("Erro")){
            selecaoModoExibicao.setSelection(0);
        }

        //Casas decimais

        valorCasasDecimais.setText(String.valueOf(recuperaPreferencias.getInt("casasDecimais",3)));

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();

        switch (id){

            case android.R.id.home:
                voltar();
                break;

        }

        return super.onOptionsItemSelected(item);
    }

    public void voltar(){
        finish();
    }

    public void gravarPreferencias(View view){
        SharedPreferences prefs = getSharedPreferences("Preferencias", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();

        editor.putString("modoExibicaoValores", (String) selecaoModoExibicao.getSelectedItem());


        if (valorCasasDecimais != null && valorCasasDecimais.getTextSize() >0) {

            if (Integer.parseInt(valorCasasDecimais.getText().toString()) >7){
                casasDecimais=7;
                valorCasasDecimais.setText("7");
            }

            if (Integer.parseInt(valorCasasDecimais.getText().toString()) <1){
                casasDecimais=1;
                valorCasasDecimais.setText("1");
            }

            casasDecimais = Integer.parseInt(valorCasasDecimais.getText().toString());
        }
        else {
            casasDecimais = 0;
        }


        editor.putInt("casasDecimais", casasDecimais);

        editor.apply();

        Toast.makeText(this,"Preferência gravada com sucesso!", Toast.LENGTH_SHORT).show();
    }
}
